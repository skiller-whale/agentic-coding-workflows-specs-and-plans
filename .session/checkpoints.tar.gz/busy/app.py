"""Shows the city map in the terminal. Run with `python app.py`; press q to quit."""

from rich.text import Text
from textual.app import App
from textual.widgets import Footer, Header, Static

from car import Car
from city import BUILDING, PARK, ROAD, City
from delivery import DeliveryBoard
from traffic_lights import NS_GREEN, TrafficLights

# How each kind of cell is drawn: (character, style).
CELL_STYLES = {
    ROAD: (" ", "on grey30"),
    BUILDING: ("▒", "tan on grey19"),
    PARK: ("♣", "green on dark_green"),
}

# How many cars make up the fleet.
FLEET_SIZE = 5

# Each car is drawn on top of whatever cell it's on, in its own distinct
# colour so the fleet stays visually distinguishable.
CAR_STYLES = [
    ("●", "bold yellow on grey30"),
    ("●", "bold magenta on grey30"),
    ("●", "bold cyan on grey30"),
    ("●", "bold white on grey30"),
    ("●", "bold red on grey30"),
]

# A job's pickup and destination buildings are drawn in their own colours,
# on top of the ordinary building styling.
PICKUP_STYLE = ("▒", "black on dark_orange")
DESTINATION_STYLE = ("▒", "black on deep_sky_blue3")

# A lit junction is drawn in the colour of its current phase: green while
# north-south has right of way, red while east-west does.
NS_GREEN_LIGHT_STYLE = ("●", "bold green on grey30")
EW_GREEN_LIGHT_STYLE = ("●", "bold red on grey30")


def draw(city, cars=(), jobs=(), traffic_lights=None):
    highlights = {}
    for job in jobs:
        if not job.collected:
            for cell in job.pickup:
                highlights[cell] = PICKUP_STYLE
        for cell in job.destination:
            highlights[cell] = DESTINATION_STYLE

    light_styles = {}
    if traffic_lights is not None:
        style = NS_GREEN_LIGHT_STYLE if traffic_lights.phase == NS_GREEN else EW_GREEN_LIGHT_STYLE
        for cell in traffic_lights.junctions:
            light_styles[cell] = style

    # Later cars in the list are drawn on top of earlier ones at a shared cell.
    car_styles = {}
    for index, car in enumerate(cars):
        car_styles[(car.x, car.y)] = CAR_STYLES[index % len(CAR_STYLES)]

    text = Text()
    for y, row in enumerate(city.rows):
        for x, cell in enumerate(row):
            if (x, y) in car_styles:
                text.append(*car_styles[(x, y)])
            elif (x, y) in light_styles:
                text.append(*light_styles[(x, y)])
            elif (x, y) in highlights:
                text.append(*highlights[(x, y)])
            else:
                text.append(*CELL_STYLES[cell])
        text.append("\n")
    return text


def status_line(jobs_board):
    return f"Takings: £{jobs_board.takings}"


class CityApp(App):
    TITLE = "City"
    CSS = """
    Screen { align: center middle; }
    #map { width: auto; height: auto; }
    #status { width: auto; }
    """
    BINDINGS = [("q", "quit", "Quit")]

    def __init__(self):
        super().__init__()
        self.city = City.load()
        self.jobs_board = DeliveryBoard(self.city)
        self.traffic_lights = TrafficLights(self.city)
        self.cars = [
            Car(self.city, self.jobs_board, self.traffic_lights) for _ in range(FLEET_SIZE)
        ]

    def compose(self):
        yield Header()
        yield Static(self._draw_map(), id="map")
        yield Static(status_line(self.jobs_board), id="status")
        yield Footer()

    def on_mount(self):
        self.set_interval(1 / 4, self.drive)
        self.set_interval(1, self.tick_jobs)
        self.set_interval(1, self.tick_lights)

    def drive(self):
        for car in self.cars:
            car.move()
        self.redraw()

    def tick_jobs(self):
        self.jobs_board.tick()
        self.redraw()

    def tick_lights(self):
        self.traffic_lights.tick()
        self.redraw()

    def redraw(self):
        self.query_one("#map", Static).update(self._draw_map())
        self.query_one("#status", Static).update(status_line(self.jobs_board))

    def _draw_map(self):
        return draw(self.city, self.cars, self.jobs_board.jobs, self.traffic_lights)


if __name__ == "__main__":
    CityApp().run()
