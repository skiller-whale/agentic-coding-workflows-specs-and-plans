import random

from city import City
from delivery import DeliveryBoard, DeliveryJob

# Exactly two isolated buildings - enough for one job, nothing left over.
TWO_BUILDINGS_MAP = City(["#.#"])

# Seven isolated buildings in a row, none orthogonally adjacent, with a
# connecting corridor beneath so every building is reachable from every
# other - enough to fill the 3-job cap with buildings to spare.
MANY_BUILDINGS_MAP = City(
    [
        "#.#.#.#.#.#.#",
        ".............",
    ]
)


def test_a_jobs_payout_is_stored_unchanged():
    job = DeliveryJob(frozenset({(0, 0)}), frozenset({(2, 0)}), payout=15)
    assert job.payout == 15


def test_a_spawned_jobs_pickup_and_destination_differ():
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(0))
    for _ in range(3):
        board.tick()
    assert len(board.jobs) == 1
    job = board.jobs[0]
    assert job.pickup != job.destination


def test_a_spawned_jobs_payout_matches_its_route_distance():
    # TWO_BUILDINGS_MAP is "#.#": a single road cell, shared by both
    # buildings, so the shortest route between them is that one cell.
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(0))
    for _ in range(3):
        board.tick()
    job = board.jobs[0]
    assert job.payout == 10 + 1


def test_no_spawn_once_the_cap_is_reached():
    board = DeliveryBoard(MANY_BUILDINGS_MAP, random=random.Random(1))
    for _ in range(9):  # three spawn attempts, at ticks 3, 6 and 9
        board.tick()
    assert len(board.jobs) == 3

    for _ in range(3):  # a fourth spawn attempt, at tick 12
        board.tick()
    assert len(board.jobs) == 3


def test_jobs_never_share_a_building():
    board = DeliveryBoard(MANY_BUILDINGS_MAP, random=random.Random(2))
    for _ in range(9):
        board.tick()
    assert len(board.jobs) == 3

    used = [building for job in board.jobs for building in (job.pickup, job.destination)]
    assert len(used) == len(set(used))


def test_no_spawn_when_fewer_than_two_buildings_are_free():
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(3))
    for _ in range(3):  # first spawn attempt uses up both buildings
        board.tick()
    assert len(board.jobs) == 1

    for _ in range(3):  # second spawn attempt: cap not reached, but no free buildings
        board.tick()
    assert len(board.jobs) == 1


def test_collect_marks_a_job_collected_without_removing_it():
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(5))
    for _ in range(3):
        board.tick()
    job = board.jobs[0]

    board.collect(job)

    assert job.collected is True
    assert job in board.jobs
    assert board.waiting_jobs() == []


def test_collecting_a_job_frees_its_pickup_but_not_its_destination():
    board = DeliveryBoard(MANY_BUILDINGS_MAP, random=random.Random(6))
    for _ in range(3):
        board.tick()
    job = board.jobs[0]

    board.collect(job)

    assert job.pickup not in board.busy_buildings()
    assert job.destination in board.busy_buildings()
    assert job.pickup in [b for b in board.free_buildings()]


def test_a_collected_job_does_not_expire():
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(7))
    for _ in range(3):
        board.tick()
    job = board.jobs[0]
    board.collect(job)

    for _ in range(100):
        board.tick()

    assert job in board.jobs


def test_a_collected_job_does_not_count_toward_the_spawn_cap():
    board = DeliveryBoard(MANY_BUILDINGS_MAP, random=random.Random(8))
    for _ in range(9):  # fill the cap: 3 waiting jobs
        board.tick()
    assert len(board.waiting_jobs()) == 3

    board.collect(board.jobs[0])
    assert len(board.waiting_jobs()) == 2

    for _ in range(3):  # next spawn-attempt tick: room for a 4th job
        board.tick()
    assert len(board.waiting_jobs()) == 3
    assert len(board.jobs) == 4


def test_deliver_removes_the_job_and_frees_its_destination():
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(9))
    for _ in range(3):
        board.tick()
    job = board.jobs[0]
    board.collect(job)

    board.deliver(job)

    assert job not in board.jobs
    assert job.destination not in board.busy_buildings()


def test_takings_start_at_zero():
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(9))
    assert board.takings == 0


def test_delivering_a_job_adds_its_payout_to_takings():
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(9))
    for _ in range(3):
        board.tick()
    job = board.jobs[0]
    board.collect(job)

    board.deliver(job)

    assert board.takings == job.payout


def test_takings_accumulate_across_deliveries():
    board = DeliveryBoard(MANY_BUILDINGS_MAP, random=random.Random(10))
    for _ in range(9):  # fill the cap: 3 waiting jobs
        board.tick()
    first_job, second_job = board.jobs[0], board.jobs[1]

    board.collect(first_job)
    board.deliver(first_job)
    board.collect(second_job)
    board.deliver(second_job)

    assert board.takings == first_job.payout + second_job.payout


def test_claiming_a_job_excludes_it_from_unclaimed_waiting_jobs():
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(9))
    for _ in range(3):
        board.tick()
    job = board.jobs[0]

    board.claim(job)

    assert job not in board.unclaimed_waiting_jobs()
    assert job in board.waiting_jobs()
    assert job in board.jobs


def test_an_expired_claim_is_released():
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(4))
    for _ in range(3):  # job spawns on the 3rd tick
        board.tick()
    job = board.jobs[0]
    board.claim(job)

    for _ in range(15):  # the job expires 15 ticks after it spawned
        board.tick()

    assert job not in board.jobs
    assert job not in board.claimed


def test_a_delivered_claim_is_released():
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(9))
    for _ in range(3):
        board.tick()
    job = board.jobs[0]
    board.claim(job)

    board.collect(job)
    board.deliver(job)

    assert job not in board.claimed


def test_a_job_expires_fifteen_ticks_after_it_spawned():
    board = DeliveryBoard(TWO_BUILDINGS_MAP, random=random.Random(4))
    for _ in range(3):  # job spawns on the 3rd tick
        board.tick()
    assert len(board.jobs) == 1
    expiring_job = board.jobs[0]

    for _ in range(14):
        board.tick()
    assert board.jobs == [expiring_job]  # still the same job after 14 more ticks (17 total)

    board.tick()  # the 15th tick since it spawned
    # The job is gone - its buildings are free again, so (since this tick is
    # also a spawn-attempt tick) a different job may immediately take its
    # place, per the "unless still part of another waiting job" scenario.
    assert expiring_job not in board.jobs
