from app import CAR_STYLES, DESTINATION_STYLE, PICKUP_STYLE, draw, status_line
from car import Car
from city import City
from delivery import DeliveryBoard, DeliveryJob
from traffic_lights import EW_GREEN, NS_GREEN, TrafficLights


def style_at(text, city, x, y):
    """The style of the cell at (x, y), by its position among draw()'s per-cell appends."""
    return text.spans[y * city.width + x].style


def test_the_car_is_drawn_over_its_cell():
    city = City.load()
    car = Car(city, DeliveryBoard(city))
    plain_text = draw(city)
    car_text = draw(city, [car])

    offset = car.y * (city.width + 1) + car.x

    assert car_text.plain[offset] != plain_text.plain[offset]
    assert car_text.plain[offset] == "●"


def test_only_the_cars_cell_changes():
    city = City.load()
    car = Car(city, DeliveryBoard(city))
    plain_text = draw(city)
    car_text = draw(city, [car])

    offset = car.y * (city.width + 1) + car.x
    without_car = car_text.plain[:offset] + plain_text.plain[offset] + car_text.plain[offset + 1 :]

    assert without_car == plain_text.plain


def test_each_car_is_drawn_in_its_own_colour():
    city = City.load()
    board = DeliveryBoard(city)
    cars = [Car(city, board) for _ in range(5)]
    for index, car in enumerate(cars):
        car.x, car.y = index, 0  # spread the cars across distinct cells

    car_text = draw(city, cars)

    styles = [style_at(car_text, city, car.x, car.y) for car in cars]
    assert styles == [CAR_STYLES[index][1] for index in range(5)]
    assert len(set(styles)) == 5


def test_two_cars_sharing_a_cell_draw_without_error():
    city = City.load()
    board = DeliveryBoard(city)
    first_car = Car(city, board)
    second_car = Car(city, board)
    second_car.x, second_car.y = first_car.x, first_car.y

    car_text = draw(city, [first_car, second_car])

    # The later car in the list is drawn on top.
    assert style_at(car_text, city, second_car.x, second_car.y) == CAR_STYLES[1][1]


def test_pickup_and_destination_buildings_are_highlighted_distinctly():
    city = City.load()
    pickup_building, destination_building = city.buildings[0], city.buildings[1]
    job = DeliveryJob(pickup_building, destination_building)

    plain_text = draw(city)
    jobs_text = draw(city, jobs=[job])

    px, py = next(iter(pickup_building))
    dx, dy = next(iter(destination_building))

    assert style_at(jobs_text, city, px, py) == PICKUP_STYLE[1]
    assert style_at(jobs_text, city, dx, dy) == DESTINATION_STYLE[1]
    assert style_at(jobs_text, city, px, py) != style_at(plain_text, city, px, py)
    assert style_at(jobs_text, city, px, py) != style_at(jobs_text, city, dx, dy)


def test_collected_jobs_pickup_highlight_is_removed_but_destination_remains():
    city = City.load()
    pickup_building, destination_building = city.buildings[0], city.buildings[1]
    job = DeliveryJob(pickup_building, destination_building)
    job.collected = True

    plain_text = draw(city)
    jobs_text = draw(city, jobs=[job])

    px, py = next(iter(pickup_building))
    dx, dy = next(iter(destination_building))

    assert style_at(jobs_text, city, px, py) == style_at(plain_text, city, px, py)
    assert style_at(jobs_text, city, dx, dy) == DESTINATION_STYLE[1]


def test_status_line_shows_the_current_takings():
    city = City.load()
    board = DeliveryBoard(city)
    board.takings = 37

    assert "£37" in status_line(board)


def test_only_job_building_cells_change_style():
    city = City.load()
    pickup_building, destination_building = city.buildings[0], city.buildings[1]
    job = DeliveryJob(pickup_building, destination_building)

    plain_text = draw(city)
    jobs_text = draw(city, jobs=[job])

    changed_cells = {
        (x, y)
        for y in range(city.height)
        for x in range(city.width)
        if style_at(jobs_text, city, x, y) != style_at(plain_text, city, x, y)
    }

    assert changed_cells == set(pickup_building) | set(destination_building)


def test_a_lit_junctions_colour_follows_its_phase():
    city = City.load()
    lights = TrafficLights(city)
    junction = next(iter(lights.junctions))

    lights.phase = NS_GREEN
    ns_text = draw(city, traffic_lights=lights)
    lights.phase = EW_GREEN
    ew_text = draw(city, traffic_lights=lights)

    jx, jy = junction
    assert style_at(ns_text, city, jx, jy) != style_at(ew_text, city, jx, jy)


def test_a_car_on_a_lit_junction_is_drawn_on_top_of_the_light():
    city = City.load()
    lights = TrafficLights(city)
    junction = next(iter(lights.junctions))
    car = Car(city, DeliveryBoard(city))
    car.x, car.y = junction

    car_text = draw(city, [car], traffic_lights=lights)

    jx, jy = junction
    assert style_at(car_text, city, jx, jy) == CAR_STYLES[0][1]


def test_only_junction_cells_change_style_between_phases():
    city = City.load()
    lights = TrafficLights(city)

    lights.phase = NS_GREEN
    ns_text = draw(city, traffic_lights=lights)
    lights.phase = EW_GREEN
    ew_text = draw(city, traffic_lights=lights)

    changed_cells = {
        (x, y)
        for y in range(city.height)
        for x in range(city.width)
        if style_at(ns_text, city, x, y) != style_at(ew_text, city, x, y)
    }

    assert changed_cells == lights.junctions
