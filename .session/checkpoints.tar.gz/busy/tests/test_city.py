from city import BUILDING, City

# A 2x2 building, two separate single-cell buildings, and a park, to check
# that building grouping follows contiguity rather than cell type alone.
BUILDING_MAP = City(
    [
        ".....",
        ".##.T",
        ".##.#",
        ".....",
        ".#...",
    ]
)


def test_the_map_is_a_rectangle():
    city = City.load()
    assert all(len(row) == city.width for row in city.rows)


def test_the_top_left_corner_is_a_road():
    assert City.load().is_road(0, 0)


def test_road_neighbors_at_a_junction():
    city = City.load()
    assert set(city.road_neighbors(3, 3)) == {(3, 2), (3, 4), (2, 3), (4, 3)}


def test_road_neighbors_in_a_corridor():
    city = City.load()
    assert set(city.road_neighbors(1, 0)) == {(0, 0), (2, 0)}


def test_road_neighbors_at_a_map_corner():
    city = City.load()
    assert set(city.road_neighbors(0, 0)) == {(1, 0), (0, 1)}


def test_all_road_cells_are_roads():
    city = City.load()
    assert all(city.is_road(x, y) for x, y in city.all_road_cells())
    assert len(city.all_road_cells()) > 0


# A mix of junction kinds: (2, 1) and (2, 3) are true 4-way crossroads,
# (3, 1) is a 3-way junction (no road to its south), and (0, 0) is a
# corner with only one open direction.
JUNCTION_KINDS_MAP = City(
    [
        ".#...",
        ".....",
        ".#.#.",
        ".....",
        ".#...",
    ]
)


def test_junctions_are_cells_with_all_four_neighbours_as_road():
    assert set(JUNCTION_KINDS_MAP.junctions()) == {(2, 1), (2, 3)}


def test_contiguous_building_cells_form_one_building():
    assert frozenset({(1, 1), (2, 1), (1, 2), (2, 2)}) in BUILDING_MAP.buildings


def test_non_adjacent_building_cells_form_separate_buildings():
    assert len(BUILDING_MAP.buildings) == 3


def test_every_building_cell_belongs_to_exactly_one_building():
    building_cells = [cell for building in BUILDING_MAP.buildings for cell in building]
    assert len(building_cells) == len(set(building_cells))
    assert set(building_cells) == {
        (x, y)
        for y in range(BUILDING_MAP.height)
        for x in range(BUILDING_MAP.width)
        if BUILDING_MAP.cell(x, y) == BUILDING
    }


def test_road_and_park_cells_belong_to_no_building():
    building_cells = {cell for building in BUILDING_MAP.buildings for cell in building}
    non_building_cells = {
        (x, y)
        for y in range(BUILDING_MAP.height)
        for x in range(BUILDING_MAP.width)
        if BUILDING_MAP.cell(x, y) != BUILDING
    }
    assert building_cells.isdisjoint(non_building_cells)


# A straight corridor ending at a single-cell building - exactly one
# shortest route, with no branching to introduce ambiguity.
CORRIDOR_TO_BUILDING_MAP = City(["....#"])

# Two road regions split by a wall column, so a building on one side is
# unreachable from the other.
SPLIT_MAP = City(
    [
        "..#..",
        "..#.#",
        "..#..",
    ]
)


def test_route_to_building_matches_the_known_shortest_path():
    building = frozenset({(4, 0)})
    path = CORRIDOR_TO_BUILDING_MAP.route_to_building((0, 0), building)
    assert path == [(0, 0), (1, 0), (2, 0), (3, 0)]


def test_route_to_building_is_a_single_cell_when_already_adjacent():
    building = frozenset({(4, 0)})
    path = CORRIDOR_TO_BUILDING_MAP.route_to_building((3, 0), building)
    assert path == [(3, 0)]


def test_route_to_building_is_none_when_unreachable():
    building = frozenset({(4, 1)})
    assert SPLIT_MAP.route_to_building((0, 0), building) is None


# A straight corridor with a building at each end, several cells apart.
CORRIDOR_BETWEEN_BUILDINGS_MAP = City(["#...#"])

# Two single-cell buildings sharing one road cell between them.
ADJACENT_BUILDINGS_MAP = City(["#.#"])

# Two single-cell buildings either side of a wall that spans the full
# height of the map, so there is no road route between them at all.
UNREACHABLE_BUILDINGS_MAP = City(
    [
        "#.#.#",
        "..#..",
    ]
)


def test_route_between_buildings_matches_the_known_shortest_path():
    building_a = frozenset({(0, 0)})
    building_b = frozenset({(4, 0)})
    path = CORRIDOR_BETWEEN_BUILDINGS_MAP.route_between_buildings(building_a, building_b)
    assert path == [(1, 0), (2, 0), (3, 0)]


def test_route_between_adjacent_buildings_is_a_single_cell():
    building_a = frozenset({(0, 0)})
    building_b = frozenset({(2, 0)})
    path = ADJACENT_BUILDINGS_MAP.route_between_buildings(building_a, building_b)
    assert path == [(1, 0)]


def test_route_between_buildings_is_none_when_unreachable():
    building_a = frozenset({(0, 0)})
    building_b = frozenset({(4, 0)})
    assert UNREACHABLE_BUILDINGS_MAP.route_between_buildings(building_a, building_b) is None
