from city import City
from traffic_lights import EW_GREEN, NS_GREEN, TrafficLights, select_junctions


def _grid_city(width, height):
    """A regular road grid: road at every x%3==0 or y%3==0, the same pattern as the real map."""
    rows = []
    for y in range(height):
        if y % 3 == 0:
            rows.append("." * width)
        else:
            rows.append("".join("." if x % 3 == 0 else "#" for x in range(width)))
    return City(rows)


# Exactly one 4-way junction per quadrant: (3, 3), (6, 3), (3, 6), (6, 6).
ONE_JUNCTION_PER_QUADRANT_MAP = _grid_city(9, 9)

# Four 4-way junctions per quadrant, so the nearest-to-centre tie-break is
# actually exercised rather than being the only candidate.
MANY_JUNCTIONS_PER_QUADRANT_MAP = _grid_city(15, 15)


def test_selects_one_junction_per_quadrant():
    chosen = select_junctions(ONE_JUNCTION_PER_QUADRANT_MAP)
    assert set(chosen) == {(3, 3), (6, 3), (3, 6), (6, 6)}


def test_selects_the_junction_nearest_each_quadrants_centre():
    chosen = select_junctions(MANY_JUNCTIONS_PER_QUADRANT_MAP)
    assert set(chosen) == {(3, 3), (12, 3), (3, 12), (12, 12)}


def test_the_real_map_has_four_junctions_one_per_quadrant():
    city = City.load()
    chosen = select_junctions(city)
    assert len(chosen) == 4

    mid_x, mid_y = city.width / 2, city.height / 2

    def quadrant(cell):
        x, y = cell
        return (0 if x < mid_x else 1, 0 if y < mid_y else 1)

    assert len({quadrant(cell) for cell in chosen}) == 4


def test_phase_starts_north_south_green():
    lights = TrafficLights(ONE_JUNCTION_PER_QUADRANT_MAP)
    assert lights.phase == NS_GREEN


def test_phase_holds_for_two_ticks_then_flips_on_the_third():
    lights = TrafficLights(ONE_JUNCTION_PER_QUADRANT_MAP)
    lights.tick()
    assert lights.phase == NS_GREEN
    lights.tick()
    assert lights.phase == NS_GREEN
    lights.tick()
    assert lights.phase == EW_GREEN


def test_phase_keeps_alternating_across_many_ticks():
    lights = TrafficLights(ONE_JUNCTION_PER_QUADRANT_MAP)
    seen = [lights.phase]
    for _ in range(20 * 3):
        lights.tick()
        seen.append(lights.phase)

    switches = [phase for phase, next_phase in zip(seen, seen[1:]) if phase != next_phase]
    assert len(switches) == 20
    assert all(phase == NS_GREEN for phase in switches[0::2])
    assert all(phase == EW_GREEN for phase in switches[1::2])


def test_unlit_cells_are_always_green():
    lights = TrafficLights(ONE_JUNCTION_PER_QUADRANT_MAP)
    assert lights.is_green((0, 0), NS_GREEN) is True
    assert lights.is_green((0, 0), EW_GREEN) is True


def test_a_lit_junction_is_green_on_the_phases_axis_and_red_on_the_other():
    lights = TrafficLights(ONE_JUNCTION_PER_QUADRANT_MAP)
    junction = next(iter(lights.junctions))

    assert lights.phase == NS_GREEN
    assert lights.is_green(junction, NS_GREEN) is True
    assert lights.is_green(junction, EW_GREEN) is False

    lights.tick()
    lights.tick()
    lights.tick()
    assert lights.phase == EW_GREEN
    assert lights.is_green(junction, NS_GREEN) is False
    assert lights.is_green(junction, EW_GREEN) is True
