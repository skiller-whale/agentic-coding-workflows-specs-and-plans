import random

from car import Car
from city import City
from delivery import DeliveryBoard, DeliveryJob
from traffic_lights import EW_GREEN, NS_GREEN, TrafficLights

# A plus-shaped junction: the centre (1, 1) has all four directions open.
JUNCTION_MAP = City(
    [
        ".#.",
        "...",
        ".#.",
    ]
)

# A vertical corridor with dead ends at the top (1, 0) and bottom (1, 3).
CORRIDOR_MAP = City(
    [
        "#.#",
        "#.#",
        "#.#",
        "#.#",
    ]
)


def empty_board(city):
    """A jobs board with nothing waiting - never ticked, so it stays empty."""
    return DeliveryBoard(city)


def goal_cells(city, building):
    """Every road cell orthogonally adjacent to a cell of `building`."""
    return {
        neighbor
        for bx, by in building
        for neighbor in city.road_neighbors(bx, by)
    }


# Two single-cell buildings at different road distances from (0, 0), with
# open rows above and below so both stay reachable around each other. Both
# are more than one move away, so a car targeting one is still en route
# (not yet collected) after its first move.
TWO_DISTANCE_MAP = City(
    [
        "..........",
        "...#...#..",
        "..........",
    ]
)
NEAR_BUILDING = frozenset({(3, 1)})
FAR_BUILDING = frozenset({(7, 1)})

# Two single-cell buildings that tie for nearest from (2, 0).
TIE_MAP = City(
    [
        ".....",
        ".#.#.",
        ".....",
    ]
)
TIE_BUILDING_A = frozenset({(1, 1)})
TIE_BUILDING_B = frozenset({(3, 1)})

# A pickup and a destination building, both reachable via the open top row.
DELIVERY_MAP = City(
    [
        "..........",
        "....#....#",
    ]
)
PICKUP_BUILDING = frozenset({(4, 1)})
DESTINATION_BUILDING = frozenset({(9, 1)})


def test_spawns_on_a_road_cell():
    for seed in range(50):
        car = Car(JUNCTION_MAP, empty_board(JUNCTION_MAP), random=random.Random(seed))
        assert JUNCTION_MAP.is_road(car.x, car.y)


def test_junction_never_reselects_the_previous_cell():
    for seed in range(50):
        car = Car(JUNCTION_MAP, empty_board(JUNCTION_MAP), random=random.Random(seed))
        car.x, car.y = (1, 1)
        car.prev = (0, 1)
        car.move()
        assert (car.x, car.y) != car.prev
        assert (car.x, car.y) in {(1, 0), (1, 2), (2, 1)}


def test_corridor_continues_through_the_only_open_direction():
    car = Car(CORRIDOR_MAP, empty_board(CORRIDOR_MAP), random=random.Random(0))
    car.x, car.y = (1, 1)
    car.prev = (1, 0)
    car.move()
    assert (car.x, car.y) == (1, 2)


def test_reverses_at_a_dead_end():
    car = Car(CORRIDOR_MAP, empty_board(CORRIDOR_MAP), random=random.Random(0))
    car.x, car.y = (1, 0)
    car.prev = (1, 1)
    car.move()
    assert (car.x, car.y) == (1, 1)


def test_stays_on_the_road_over_many_moves():
    city = City.load()
    car = Car(city, empty_board(city), random=random.Random(12345))
    for _ in range(2000):
        car.move()
        assert city.is_road(car.x, car.y)


def test_wanders_like_before_when_no_jobs_are_waiting():
    board = empty_board(JUNCTION_MAP)
    car = Car(JUNCTION_MAP, board, random=random.Random(0))
    car.x, car.y = (1, 1)
    car.prev = (0, 1)
    car.move()
    assert (car.x, car.y) != car.prev
    assert (car.x, car.y) in {(1, 0), (1, 2), (2, 1)}
    assert car.target_job is None


def test_targets_the_nearest_waiting_jobs_pickup():
    board = empty_board(TWO_DISTANCE_MAP)
    far_job = DeliveryJob(FAR_BUILDING, frozenset({(9, 0)}))
    near_job = DeliveryJob(NEAR_BUILDING, frozenset({(9, 0)}))
    board.jobs = [far_job, near_job]

    car = Car(TWO_DISTANCE_MAP, board, random=random.Random(0))
    car.x, car.y = (0, 0)
    car.prev = None
    car.move()

    assert car.target_job is near_job


def test_a_job_already_targeted_by_another_car_is_not_targeted_again():
    board = empty_board(TWO_DISTANCE_MAP)
    job = DeliveryJob(NEAR_BUILDING, frozenset({(9, 0)}))
    board.jobs = [job]

    first_car = Car(TWO_DISTANCE_MAP, board, random=random.Random(0))
    first_car.x, first_car.y = (0, 0)
    first_car.prev = None
    assert first_car._pick_target() is True
    assert first_car.target_job is job

    second_car = Car(TWO_DISTANCE_MAP, board, random=random.Random(0))
    second_car.x, second_car.y = (0, 0)
    second_car.prev = None
    assert second_car._pick_target() is False
    assert second_car.target_job is None


def test_ties_for_nearest_are_broken_at_random():
    chosen_pickups = set()
    for seed in range(20):
        board = empty_board(TIE_MAP)
        job_a = DeliveryJob(TIE_BUILDING_A, frozenset({(4, 2)}))
        job_b = DeliveryJob(TIE_BUILDING_B, frozenset({(4, 2)}))
        board.jobs = [job_a, job_b]

        car = Car(TIE_MAP, board, random=random.Random(seed))
        car.x, car.y = (2, 0)
        car.prev = None
        car.move()

        chosen_pickups.add(car.target_job.pickup)

    assert chosen_pickups == {TIE_BUILDING_A, TIE_BUILDING_B}


def test_follows_the_route_to_pickup_and_collects_on_arrival():
    board = empty_board(DELIVERY_MAP)
    job = DeliveryJob(PICKUP_BUILDING, DESTINATION_BUILDING)
    board.jobs = [job]
    pickup_goals = goal_cells(DELIVERY_MAP, PICKUP_BUILDING)

    car = Car(DELIVERY_MAP, board, random=random.Random(0))
    car.x, car.y = (0, 0)
    car.prev = None

    for _ in range(20):
        car.move()
        assert DELIVERY_MAP.is_road(car.x, car.y)
        if job.collected:
            break

    assert job.collected is True
    assert (car.x, car.y) in pickup_goals
    assert car.carrying is True
    assert car.target_job is job


def test_delivers_the_package_and_removes_the_job():
    board = empty_board(DELIVERY_MAP)
    job = DeliveryJob(PICKUP_BUILDING, DESTINATION_BUILDING)
    board.jobs = [job]
    destination_goals = goal_cells(DELIVERY_MAP, DESTINATION_BUILDING)

    car = Car(DELIVERY_MAP, board, random=random.Random(0))
    car.x, car.y = (0, 0)
    car.prev = None

    for _ in range(40):
        car.move()
        assert DELIVERY_MAP.is_road(car.x, car.y)
        if job not in board.jobs:
            break

    assert job not in board.jobs
    assert (car.x, car.y) in destination_goals
    assert car.carrying is False
    assert car.target_job is None


def test_commits_to_the_original_target_even_if_a_nearer_job_appears():
    board = empty_board(TWO_DISTANCE_MAP)
    far_job = DeliveryJob(FAR_BUILDING, frozenset({(9, 0)}))
    board.jobs = [far_job]

    car = Car(TWO_DISTANCE_MAP, board, random=random.Random(0))
    car.x, car.y = (0, 0)
    car.prev = None
    car.move()
    assert car.target_job is far_job

    near_job = DeliveryJob(NEAR_BUILDING, frozenset({(9, 0)}))
    board.jobs.append(near_job)
    car.move()

    assert car.target_job is far_job


def test_retargets_when_the_current_target_expires_before_pickup():
    board = empty_board(TWO_DISTANCE_MAP)
    far_job = DeliveryJob(FAR_BUILDING, frozenset({(9, 0)}))
    near_job = DeliveryJob(NEAR_BUILDING, frozenset({(9, 0)}))
    board.jobs = [far_job, near_job]

    car = Car(TWO_DISTANCE_MAP, board, random=random.Random(0))
    car.x, car.y = (0, 0)
    car.prev = None
    car.move()
    assert car.target_job is near_job

    board.jobs.remove(near_job)  # the targeted job expires before arrival
    car.move()

    assert car.target_job is far_job


def test_wanders_again_when_the_only_target_expires():
    board = empty_board(TWO_DISTANCE_MAP)
    near_job = DeliveryJob(NEAR_BUILDING, frozenset({(9, 0)}))
    board.jobs = [near_job]

    car = Car(TWO_DISTANCE_MAP, board, random=random.Random(0))
    car.x, car.y = (0, 0)
    car.prev = None
    car.move()
    assert car.target_job is near_job

    board.jobs.remove(near_job)
    car.move()

    assert car.target_job is None
    assert TWO_DISTANCE_MAP.is_road(car.x, car.y)


# A single-row corridor with a building at the far end - no branching, so
# there is exactly one shortest route and it passes through (2, 0).
LIGHT_CORRIDOR_MAP = City(["....#"])
LIGHT_PICKUP_BUILDING = frozenset({(4, 0)})
LIGHT_DESTINATION_BUILDING = frozenset({(0, 0)})


def test_a_car_following_a_route_waits_at_a_red_light_then_proceeds():
    board = empty_board(LIGHT_CORRIDOR_MAP)
    job = DeliveryJob(LIGHT_PICKUP_BUILDING, LIGHT_DESTINATION_BUILDING)
    board.jobs = [job]

    lights = TrafficLights(LIGHT_CORRIDOR_MAP)
    lights.junctions = {(2, 0)}
    lights.phase = NS_GREEN  # red for this east-west route

    car = Car(LIGHT_CORRIDOR_MAP, board, traffic_lights=lights, random=random.Random(0))
    car.x, car.y = (0, 0)
    car.prev = None

    car.move()  # claims the job and takes its first, unlit, step
    assert (car.x, car.y) == (1, 0)
    assert car.target_job is job

    for _ in range(5):  # held at the red light, not skipping ahead into (2, 0)
        car.move()
        assert (car.x, car.y) == (1, 0)
    assert car.route == [(2, 0), (3, 0)]

    lights.phase = EW_GREEN  # now green for east-west
    car.move()
    assert (car.x, car.y) == (2, 0)  # proceeds onto the junction itself

    lights.phase = NS_GREEN  # red again, but the light only blocks entry
    car.move()
    assert (car.x, car.y) == (3, 0)  # leaving the junction is unaffected


# A single-row corridor, no branching, so a car at either end has exactly
# one open neighbour - the move it must decide on is deterministic.
WANDER_LIGHT_MAP = City(["....."])


def test_a_wandering_car_waits_at_a_red_light_then_proceeds():
    board = empty_board(WANDER_LIGHT_MAP)
    lights = TrafficLights(WANDER_LIGHT_MAP)
    lights.junctions = {(1, 0)}
    lights.phase = NS_GREEN  # red for this east-west move

    car = Car(WANDER_LIGHT_MAP, board, traffic_lights=lights, random=random.Random(0))
    car.x, car.y = (0, 0)
    car.prev = None

    for _ in range(5):  # held at the red light, still committed to (1, 0)
        car.move()
        assert (car.x, car.y) == (0, 0)
        assert car._waiting_cell == (1, 0)

    lights.phase = EW_GREEN  # now green for east-west
    car.move()
    assert (car.x, car.y) == (1, 0)
    assert car.prev == (0, 0)

    # Once past the junction, ordinary wandering resumes: the car excludes
    # the cell it just came from, regardless of the light's phase.
    car.move()
    assert (car.x, car.y) == (2, 0)
