"""Traffic lights at a handful of junctions, cycling between north-south and east-west green."""

LIGHT_COUNT = 4  # a 2x2 grid of quadrants
PHASE_TICKS = 3  # seconds per phase, at one tick per second
NS_GREEN = "ns"
EW_GREEN = "ew"


def select_junctions(city):
    """Pick one 4-way junction per quadrant of the city, nearest that quadrant's centre."""
    eligible = city.junctions()
    mid_x, mid_y = city.width / 2, city.height / 2

    def quadrant(cell):
        x, y = cell
        return (0 if x < mid_x else 1, 0 if y < mid_y else 1)

    chosen = []
    for qy in (0, 1):
        for qx in (0, 1):
            candidates = [cell for cell in eligible if quadrant(cell) == (qx, qy)]
            if not candidates:
                continue
            center_x = city.width * (0.25 if qx == 0 else 0.75)
            center_y = city.height * (0.25 if qy == 0 else 0.75)
            chosen.append(
                min(candidates, key=lambda cell: abs(cell[0] - center_x) + abs(cell[1] - center_y))
            )
    return chosen


class TrafficLights:
    """A shared red/green phase across a fixed set of lit junctions."""

    def __init__(self, city):
        self.junctions = set(select_junctions(city))
        self.phase = NS_GREEN
        self._ticks_in_phase = 0

    def tick(self):
        self._ticks_in_phase += 1
        if self._ticks_in_phase >= PHASE_TICKS:
            self._ticks_in_phase = 0
            self.phase = EW_GREEN if self.phase == NS_GREEN else NS_GREEN

    def is_green(self, cell, axis):
        if cell not in self.junctions:
            return True
        return self.phase == axis
