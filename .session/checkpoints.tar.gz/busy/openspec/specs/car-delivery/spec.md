# car-delivery Specification

## Purpose

Gives the car a reason to move: it seeks out waiting delivery jobs, drives to collect and deliver each one by the shortest road route, and wanders at random only when there is nothing to deliver.

## Requirements

### Requirement: Target the nearest waiting job
Whenever the car is not carrying a package and has no committed pickup target, and at least one delivery job is waiting and not already targeted by another car, the car SHALL select as its target the such job whose pickup building has the shortest route along the roads from the car's current cell, measured in road cells to the nearest road cell adjacent to that building. If more than one such job ties for the shortest route, the car SHALL choose uniformly at random among the tied jobs. Once a car targets a job, no other car SHALL target that same job while it remains that car's committed target.

#### Scenario: One waiting job
- **WHEN** exactly one delivery job is waiting and the car has no target
- **THEN** the car targets that job's pickup building

#### Scenario: Several waiting jobs at different distances
- **WHEN** more than one delivery job is waiting and the car has no target
- **THEN** the car targets the waiting job whose pickup building has the shortest road route from the car's current cell

#### Scenario: A tie for nearest
- **WHEN** two or more waiting jobs' pickup buildings have an equally short road route from the car's current cell, and that route is no longer than any other waiting job's
- **THEN** the car targets one of those tied jobs, chosen at random

#### Scenario: A job already targeted by another car is skipped
- **WHEN** a delivery job is already another car's committed target, and it is the nearest waiting job to a second, idle car
- **THEN** the second car does not target that job, and instead targets the nearest waiting job not already targeted by any car, or drives at random if no such job is waiting

### Requirement: Commit to a chosen pickup target
Once the car has targeted a job's pickup, it SHALL continue toward that job rather than switching to a different waiting job, even if another job is spawned or becomes nearer in the meantime. If the targeted job expires before the car reaches its pickup, the car SHALL immediately re-evaluate: targeting the nearest remaining waiting job, or driving at random if none are waiting.

#### Scenario: A nearer job appears en route
- **WHEN** the car is already en route to a targeted job's pickup and a new, closer job is spawned
- **THEN** the car continues toward its original target and does not divert to the new job

#### Scenario: The targeted job expires before pickup
- **WHEN** the car's targeted job expires before the car reaches its pickup building
- **THEN** the car stops heading toward that job's pickup and, on its next move, targets the nearest remaining waiting job or drives at random if none are waiting

### Requirement: Drive the shortest route to the target
While pursuing a job's pickup or heading to its destination, the car SHALL move one road cell at a time along a shortest route, by number of road cells, from its current cell to a road cell adjacent to the target building, at the same pace as ordinary driving.

#### Scenario: Routing to a pickup
- **WHEN** the car is pursuing a job's pickup
- **THEN** each move advances it one cell along a shortest road route toward a road cell adjacent to the pickup building

#### Scenario: Routing to a destination
- **WHEN** the car is carrying a job's package
- **THEN** each move advances it one cell along a shortest road route toward a road cell adjacent to the destination building

### Requirement: Collect the package on arrival at pickup
When the car reaches a road cell adjacent to its targeted job's pickup building, it SHALL collect that job's package and immediately begin heading toward the job's destination.

#### Scenario: Arriving at the pickup
- **WHEN** the car's move brings it to a road cell adjacent to its targeted job's pickup building
- **THEN** the job's package is collected and the car's next moves head toward that job's destination

### Requirement: Carry at most one package at a time
While carrying a collected job's package, the car SHALL ignore every other waiting job until it delivers the one it carries.

#### Scenario: Other jobs wait while one is being carried
- **WHEN** the car is carrying a package and one or more other jobs are waiting
- **THEN** the car continues toward its carried job's destination and does not target any other waiting job

### Requirement: Deliver the package on arrival at destination
When the car reaches a road cell adjacent to the destination building of the job it carries, it SHALL deliver the package, removing the job, and then is free to target a new waiting job or drive at random.

#### Scenario: Arriving at the destination
- **WHEN** the car's move brings it to a road cell adjacent to the destination building of the job it carries
- **THEN** the job is removed and the car is no longer carrying a package

### Requirement: Wander when there is nothing to deliver
Whenever no delivery job is waiting and the car is not carrying one, the car SHALL drive at random, as specified by `car-driving`.

#### Scenario: No jobs waiting
- **WHEN** no delivery job is waiting and the car is not carrying a package
- **THEN** the car's movement follows the random-driving behavior instead of heading to any building
