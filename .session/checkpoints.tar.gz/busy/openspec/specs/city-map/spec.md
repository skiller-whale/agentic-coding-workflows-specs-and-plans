# city-map Specification

## Purpose
Show a fixed map of a city block in the terminal, with its roads, buildings and parks.

## Requirements

### Requirement: Fixed map
The app SHALL read the city from `city_map.txt`, where each character is one cell: `.` is road, `#` is a building and `T` is park. Cell (0, 0) is the top-left corner.

#### Scenario: Top-left corner
- **WHEN** the map is loaded
- **THEN** cell (0, 0) is a road

### Requirement: Draw the map
The app SHALL draw every cell of the map, with roads, buildings and parks each in their own colour.

#### Scenario: Start the app
- **WHEN** someone runs `python app.py`
- **THEN** the whole map is shown, and `q` quits

### Requirement: Buildings are identified as groups of cells
The city's map data SHALL group orthogonally-contiguous building cells into individual buildings, so a building can be addressed as a whole rather than as individual cells.

#### Scenario: A multi-cell building is one building
- **WHEN** the map is loaded
- **THEN** each maximal orthogonally-connected group of building cells forms exactly one building, separate from every other such group

#### Scenario: Building cells belong to exactly one building
- **WHEN** the map is loaded
- **THEN** every building cell belongs to exactly one building, and no road or park cell belongs to any building

### Requirement: All buildings are enumerable
The city SHALL expose the full list of identified buildings so other capabilities can select among them.

#### Scenario: Every building is included
- **WHEN** the map is loaded
- **THEN** the list of buildings includes every building cell group in the map, and no building appears more than once
