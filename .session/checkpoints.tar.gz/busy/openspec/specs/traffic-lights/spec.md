# traffic-lights Specification

## Purpose

Control traffic at a subset of the city's junctions with cycling red/green lights, so cars must obey a visible rule of the road rather than crossing every junction unimpeded.

## Requirements

### Requirement: Lights are placed on four junctions spread across the map
The app SHALL place a traffic light on exactly four road junctions, each a cell where all four orthogonal neighbours are road cells, chosen so that one falls in each quadrant of the map.

#### Scenario: Four lit junctions, one per quadrant
- **WHEN** the city loads
- **THEN** exactly four junctions have a traffic light, and each lies in a different quarter of the map's bounding box

#### Scenario: A lit junction is a true crossroads
- **WHEN** a junction is chosen for a light
- **THEN** all four of its orthogonal neighbours are road cells

### Requirement: Each light cycles between north-south and east-west green
Each traffic light SHALL be in one of two phases, north-south green (east-west red) or east-west green (north-south red), switching to the other phase every 3 seconds.

#### Scenario: Phase switches after three seconds
- **WHEN** a light has been in one phase for 3 seconds
- **THEN** it switches to the other phase

#### Scenario: Only one axis is ever green
- **WHEN** a light is in either phase
- **THEN** exactly one of north-south or east-west is green and the other is red

### Requirement: A lit junction is drawn in its current phase's colour
While the app is running, each lit junction SHALL be drawn on the map in a colour that reflects its current phase, distinct for north-south-green and east-west-green.

#### Scenario: Light colour follows its phase
- **WHEN** a lit junction's phase changes
- **THEN** the colour it is drawn in changes to match the new phase

#### Scenario: A car on a lit junction is still visible
- **WHEN** a car occupies a cell that has a traffic light
- **THEN** the car is drawn on top of the light
