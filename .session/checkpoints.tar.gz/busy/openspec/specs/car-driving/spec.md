# car-driving Specification

## Purpose

A car drives around the city's road network at random, forever, so the running app shows a city with movement in it rather than a static map.

## Requirements

### Requirement: Spawn on a random road cell
The car SHALL start on a road cell chosen uniformly at random from every road cell in the city.

#### Scenario: Spawn position is always a road
- **WHEN** the car is created
- **THEN** its starting cell is a road cell

### Requirement: Move one road cell at a time, at a fixed pace
The car SHALL advance by exactly one cell per move, moving only between orthogonally adjacent cells (north, south, east or west) that are both road cells, about 4 times per second while the app is running.

#### Scenario: A single move
- **WHEN** the car moves
- **THEN** its new cell is a road cell orthogonally adjacent to its previous cell

### Requirement: Random direction at a junction, no reversing except at a dead end
While the car has no delivery job to pursue and is not carrying one, each time it moves it SHALL choose uniformly at random among the open directions, where "open" means leading to an adjacent road cell and excluding the direction back to the cell the car just came from. If excluding that direction leaves no open direction (a dead end), the car SHALL reverse back the way it came instead. While pursuing or carrying a delivery job, the car's direction is instead governed by `car-delivery`.

#### Scenario: Choosing among several open directions
- **WHEN** the car has no delivery job to pursue or carry, and is at a cell where more than one direction (other than the way it came) is open
- **THEN** the car moves to one of those open cells, chosen at random, and never to the cell it just came from

#### Scenario: Continuing through a cell with one open direction
- **WHEN** the car has no delivery job to pursue or carry, and is at a cell where exactly one direction (other than the way it came) is open
- **THEN** the car moves to that cell

#### Scenario: Reversing at a dead end
- **WHEN** the car has no delivery job to pursue or carry, and is at a cell where no direction is open except the way it came
- **THEN** the car moves back to the cell it just came from

### Requirement: The car is always on a road
The car's position SHALL be a road cell at all times; it SHALL never move onto a building or park cell or outside the map.

#### Scenario: Long run stays on the road
- **WHEN** the car makes any number of moves
- **THEN** every cell it has ever occupied is a road cell

### Requirement: The car is drawn as a bright symbol
While the app is running, the car SHALL be drawn on top of the map at its current position, using a symbol and style that stand out against the road, building and park colours.

#### Scenario: The car is visible on the map
- **WHEN** someone runs `python app.py`
- **THEN** the car appears on the map at its current cell, redrawn as it moves

### Requirement: Wait at a red light before entering a lit junction
Before moving onto a cell that is a lit junction (see `traffic-lights`), the car SHALL check whether the light is green for its direction of travel. If red, the car SHALL NOT move this tick and SHALL instead retry the same move on its next tick; it SHALL move onto the junction once the light turns green. This applies regardless of whether the car is wandering, pursuing a pickup, or carrying a delivery.

#### Scenario: Waiting at a red light
- **WHEN** the car's next move would enter a lit junction and the light is red for its direction of travel
- **THEN** the car's position does not change this tick

#### Scenario: Proceeding on green
- **WHEN** the car's next move would enter a lit junction and the light is green for its direction of travel
- **THEN** the car moves onto the junction cell as normal

#### Scenario: A waiting car still proceeds once the light turns green
- **WHEN** the car has waited at a red light and the light then turns green for its direction of travel
- **THEN** the car moves onto the junction cell on its next move, without re-choosing a different direction
