# Design

## Context

See proposal.md - Why. Relevant existing code:

- `City.route_to_building(start, building)` (city.py) does a BFS from a single cell to the nearest road cell adjacent to a building. It takes one building, not two, so it can't directly answer "what's the route between this pickup and this destination?".
- `DeliveryJob` (delivery.py) currently holds just `pickup`, `destination`, `ticks_remaining`, `collected`.
- `DeliveryBoard` (delivery.py) owns job spawn/collect/deliver/expiry and is already the thing `Car` calls into for every job state change, including `deliver(job)`.
- `app.py` composes `City`, `DeliveryBoard` and `Car`, draws the map in one `Static` widget, and redraws on two timers (`drive` at 4Hz, `tick_jobs` at 1Hz).

## Goals / Non-Goals

**Goals:**
- Compute each job's payout once, consistently, from the existing road graph.
- Keep the payout a property of the job (so `delivery-jobs` scenarios like "payout doesn't change after spawn" hold trivially).
- Keep the running total and its display decoupled from `Car`, matching the existing separation where `Car` reacts to `DeliveryBoard` but doesn't own job data.

**Non-Goals:**
- No spending, upgrades, or multiple cars. Takings only ever go up.
- No change to job spawn timing, caps, or expiry rules.
- No persistence across app restarts.

## Decisions

**Routing between two buildings: add `City.route_between_buildings(building_a, building_b)`.**
Reuses the existing BFS shape but seeds the frontier with every road cell adjacent to `building_a` (instead of a single start cell) and searches for any road cell adjacent to `building_b`, returning the shortest such path. This is the natural generalization of `route_to_building` rather than a bolt-on: `route_to_building(start, building)` becomes the special case where the start set has one member. Alternative considered: loop over each pickup-adjacent cell and call `route_to_building` per cell, keeping the minimum — rejected as O(k) BFS passes for no benefit when a single multi-source BFS does it in one pass.

**Payout is computed once, at spawn, and stored on the `DeliveryJob`.**
`DeliveryBoard._attempt_spawn` already has both buildings in hand when it creates the job; it computes the route length there via `city.route_between_buildings` and sets `job.payout = 10 + len(route)`, where `len(route)` is the number of road cells in the path returned (inclusive of the start and end cells, consistent with how `route_to_building`'s length is already used for comparisons in `car-delivery`). Storing it on the job (rather than recomputing at delivery time) makes the "payout is fixed at spawn" requirement true by construction, and means delivery never needs the city/routing at all.

**The running total lives on `DeliveryBoard`, not `Car`.**
`DeliveryBoard.deliver(job)` is the one place that already knows a job has been fully delivered — `Car._deliver` just calls it. Adding `self.takings = 0` and incrementing it inside `deliver()` keeps `Car` exactly as ignorant of money as it already is of job bookkeeping. Alternative considered: a separate `Takings`/`Economy` class — rejected as unnecessary indirection for a single counter; `DeliveryBoard` is already the capability that owns the job economy (spawning, caps, expiry), so a running total of completed payouts fits the same home.

**Display: a second `Static` widget under the map, updated from both existing timers.**
`app.py` already redraws the map on `drive()` (4Hz) and `tick_jobs()` (1Hz). Since a delivery can only happen inside `Car.move()` (called from `drive`), the new status widget is refreshed in `redraw()` alongside the map, reading `self.jobs_board.takings` each time — no new timer needed. Formatting as `£{takings}` in a plain `Static` matches the terminal-only, no-dependencies style of the rest of the UI (no new library).

## Risks / Trade-offs

- [Multi-source BFS adds a small amount of routing code to `City`] → Mitigated by it being a direct generalization of the existing single-source version, testable the same way (`tests/test_city.py` already covers `route_to_building`).
- [Payout stored on the job means the formula can't retroactively change already-spawned jobs] → This is the intended behavior per the spec ("fixed for the life of the job"), not a defect.

## Open Questions

None — the user confirmed the payout formula and display location; everything else above follows from matching the existing architecture.
