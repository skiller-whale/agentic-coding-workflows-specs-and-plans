# Tasks

## 1. Routing between two buildings

- [x] 1.1 Add `City.route_between_buildings(building_a, building_b)`, a multi-source BFS from every road cell adjacent to `building_a` to the nearest road cell adjacent to `building_b`, returning the path (or `None` if unreachable) in the same shape as `route_to_building`. Verify with new cases in `tests/test_city.py`: adjacent buildings, buildings several cells apart, and an unreachable pair returning `None`.

## 2. Job payout

- [x] 2.1 Add a `payout` parameter/attribute to `DeliveryJob`, set once at construction. Verify `DeliveryJob(pickup, destination, payout=...)` stores it unchanged.
- [x] 2.2 In `DeliveryBoard._attempt_spawn`, compute the route between the chosen pickup and destination with `route_between_buildings` and construct the job with `payout = 10 + len(route)`. Verify with a new `tests/test_delivery.py` case on a small fixed map where the pickup-destination distance is known, asserting the spawned job's `payout` matches `10 + expected_route_length`.

## 3. Running takings total

- [x] 3.1 Add `self.takings = 0` to `DeliveryBoard.__init__`, and increment it by `job.payout` inside `deliver()` before the job is removed. Verify with a `tests/test_delivery.py` case that delivers a job and asserts `board.takings` equals that job's payout, and that `takings` is `0` on a freshly constructed board.
- [x] 3.2 Verify takings only ever accumulates: deliver two jobs in sequence and assert `board.takings` equals the sum of both payouts.

## 4. Status line in the UI

- [x] 4.1 Add a second `Static` widget beneath the map `Static` in `CityApp.compose()` (e.g. `id="status"`), initialized from `self.jobs_board.takings`.
- [x] 4.2 Update the status widget's text whenever `redraw()` runs, formatting takings as `£{takings}`. Verify by running `python app.py` and confirming a status line reading `£0` appears beneath the map, and that it increases as deliveries complete.
- [x] 4.3 Add a `tests/test_app.py` case (following the existing `style_at`/`draw`-style helpers) that renders the status line for a `DeliveryBoard` with a non-zero `takings` and asserts the displayed text includes the correct `£` amount.

## 5. Full-suite check

- [x] 5.1 Run `python -m pytest` and confirm the full suite passes, including the new and existing city, delivery, and app tests.
