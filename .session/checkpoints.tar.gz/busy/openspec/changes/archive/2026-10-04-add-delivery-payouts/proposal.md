# Proposal

## Why

Right now a delivery is purely cosmetic: whether the car hauls a package across the whole map or next door, nothing distinguishes the two, and the app gives no sense that the car is "earning" anything. A payout per delivery, scaled by how far the package travelled, gives each trip weight and a visible, growing number that reflects the car's work.

## What Changes

- Each delivery job is assigned a fixed payout when it spawns: £10, plus £1 for every road cell on the shortest route from its pickup building to its destination building.
- Delivering a job adds its payout to a running total of takings, which only ever increases (no spending, no costs).
- The map view gains a status line beneath the map showing the current total takings, updated live as deliveries happen.

## Capabilities

### New Capabilities
- `takings`: Accumulates a running total of money earned from completed deliveries and displays it in a status line beneath the map.

### Modified Capabilities
- `delivery-jobs`: A job now carries a fixed payout, set when it spawns, based on the road distance between its pickup and destination buildings.

## Impact

- `delivery.py`: `DeliveryJob` gains a `payout` computed at spawn time from the pickup-to-destination route; `DeliveryBoard` gains a running takings total, incremented when a job is delivered.
- `city.py`: needs a way to find the shortest road route between two buildings (not just from a car's current cell to one building, which is all `route_to_building` currently supports).
- `app.py`: a new status line widget beneath the map, showing the current takings total, refreshed whenever it changes.
