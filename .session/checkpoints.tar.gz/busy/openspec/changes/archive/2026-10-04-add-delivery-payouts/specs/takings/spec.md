# Spec Delta

## Purpose

Tracks how much money the car has earned by delivering packages, and shows that running total to whoever is watching the map.

## ADDED Requirements

### Requirement: Delivering a job adds its payout to the total takings
Whenever a job is delivered, the system SHALL add that job's payout to a running total of takings. The total SHALL start at zero and SHALL only ever increase.

#### Scenario: A delivery increases the total
- **WHEN** a job with a payout of £15 is delivered
- **THEN** the total takings increases by £15

#### Scenario: Takings start at zero
- **WHEN** the app starts and no job has yet been delivered
- **THEN** the total takings is £0

### Requirement: Total takings are shown in a status line beneath the map
While the app is running, the system SHALL display the current total takings in a status line beneath the map, formatted as an amount in pounds, and SHALL update it whenever the total changes.

#### Scenario: Takings are visible
- **WHEN** someone runs `python app.py`
- **THEN** a status line beneath the map shows the current total takings

#### Scenario: The status line updates after a delivery
- **WHEN** a job is delivered
- **THEN** the status line beneath the map reflects the new, higher total takings
