# Spec Delta

## ADDED Requirements

### Requirement: A job carries a fixed payout based on distance
Each delivery job SHALL be assigned a payout when it spawns: £10, plus £1 for every road cell on the shortest route along the roads between a road cell adjacent to its pickup building and a road cell adjacent to its destination building. The payout SHALL be fixed for the life of the job; it does not depend on the car's position, or on how or when the job is later collected or delivered.

#### Scenario: A short hop pays the base fare plus distance
- **WHEN** a job spawns whose pickup and destination buildings are joined by a shortest road route of 5 road cells
- **THEN** the job's payout is £15

#### Scenario: Payout does not change after spawn
- **WHEN** a job's payout has been set at spawn
- **THEN** the payout remains the same regardless of the car's position while pursuing, collecting, or delivering that job
