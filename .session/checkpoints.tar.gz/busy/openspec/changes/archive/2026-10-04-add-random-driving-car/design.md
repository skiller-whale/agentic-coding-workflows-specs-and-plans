# Design

## Context

`city.py` holds the fixed map and only exposes `cell(x, y)` and `is_road(x, y)`. `app.py` is a Textual app that draws the map once with `draw(city)` and otherwise just waits for `q`; it has no timer and no mutable state. The real `city_map.txt` is a fully connected grid (every road row and column spans the whole map), so it has no cell with only one open neighbour — true dead ends only arise on other maps (e.g. a stub street), but the logic must handle them generically rather than assuming this specific map.

See proposal.md for motivation and specs/car-driving/spec.md for the exact behaviour.

## Goals / Non-Goals

**Goals:**
- Add car movement and rendering without changing how the static map itself is loaded or drawn.
- Keep the movement rule generic over any map `City` can load, not special-cased to the current `city_map.txt`.
- Keep `Car`'s move-choice logic unit-testable without a running Textual app or real timing.

**Non-Goals:**
- Multiple cars, pathfinding, traffic rules (stopping at intersections, lanes, collisions) — out of scope for this change.
- Persisting or replaying a car's route.

## Decisions

**Represent "the way it came" as the previous cell, not a compass heading.**
`Car` stores `(x, y)` and `(prev_x, prev_y)` (the latter `None` right after spawn). Choosing the next cell is: take the road neighbours of `(x, y)`, drop the one equal to `(prev_x, prev_y)` if present, then `random.choice` the rest; if that leaves nothing, the only candidate is `(prev_x, prev_y)` itself, so the car reverses into it. This reads directly off the spec's "excluding the one it came from" wording and needs no heading/rotation logic.
Alternative considered: store a facing direction (N/S/E/W) and compute left/right/straight/back turns. Rejected — it's more state and more cases for a grid where "forward" isn't meaningful off of corridors, for no behavioural difference.

**`City` gains `road_neighbors(x, y)`, returning the open adjacent road cells.**
This is the one new piece `city.py` needs: a list of up to four `(x, y)` tuples among N/S/E/W that are in bounds and `is_road`. Keeps the "what is open" logic (bounds + road check) in `City`, next to `is_road`, and keeps `Car` free of grid bounds-checking.

**`Car` takes a `random` module (or `Random` instance) as a constructor argument, defaulting to the `random` module.**
Lets tests pass a seeded `random.Random(seed)` or a stub for deterministic assertions, without changing call sites that don't care.

**Drive the tick from Textual's `set_interval`, not a separate thread.**
`app.py`'s `on_mount` calls `self.set_interval(0.25, self.tick)` (4/sec); `tick` moves the car and updates the `Static` widget's renderable via `draw(city, car)`. This matches how Textual expects periodic UI updates and needs no new concurrency primitives.

**Rendering: `draw(city, car)` overlays the car's glyph while building the `Text`, rather than post-processing styled spans.**
While iterating cells, if `(x, y) == (car.x, car.y)` use a car style/glyph instead of the cell's own; otherwise unchanged. Simpler than stylizing a sub-range of an already-built `Text`, and keeps `draw` a single pass.

## Risks / Trade-offs

- [Textual timer granularity / terminal redraw cost at 4/sec] → the map is small (67x22); redrawing the whole `Text` every tick is cheap enough that no diffing is needed.
- [No real dead end exists in `city_map.txt`, so the reversal branch is untested by running the real app] → cover it with a unit test against a small synthetic map (a stub road cell) rather than relying on the shipped map.
- [`random.choice` on a list that happens to contain only the previous cell would silently "reverse" even at a non-dead-end if neighbour computation were wrong] → covered by the "stays on the road" / adjacency scenarios plus a direct unit test of `road_neighbors`.
