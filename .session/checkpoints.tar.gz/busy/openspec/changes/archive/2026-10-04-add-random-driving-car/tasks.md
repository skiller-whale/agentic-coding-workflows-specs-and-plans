# Tasks

## 1. City: road neighbours

- [x] 1.1 Add `City.road_neighbors(x, y)` returning the in-bounds, `is_road` orthogonal neighbours of `(x, y)` and verify with a unit test against the real map (a known junction, a known corridor cell, and a map-corner cell each return the expected set)

## 2. Car: spawn and move-choice logic

- [x] 2.1 Add a `Car` class (new module) that spawns on a road cell chosen uniformly at random from every road cell in the `City`, accepting an injectable `random`/`Random` source, and verify with a unit test (seeded source + a stubbed/small city) that the spawn cell is always a road cell
- [x] 2.2 Implement `Car.move()`: compute `road_neighbors` of the current cell, exclude the previous cell if present, choose uniformly at random among what's left, and if nothing's left move back into the previous cell instead; verify with unit tests covering: a junction with several open directions never re-selects the previous cell, a corridor with exactly one open direction continues through it, and (against a small synthetic map with a stub dead-end cell) the car reverses when only the previous cell is open
- [x] 2.3 Add a test that runs `Car.move()` many times against the real `City.load()` map and asserts every visited cell is a road cell

## 3. App: ticking and rendering the car

- [x] 3.1 Extend `draw(city, car)` in `app.py` to render the car's cell with a bright symbol/style distinct from road, building and park, and verify with a unit test that the car's cell in the returned `Text` differs from the plain map's rendering at that position
- [x] 3.2 Wire a `Car` instance into `CityApp`, add an `on_mount` timer via `set_interval` at 4 moves/sec that calls `Car.move()` and refreshes the `Static` widget with `draw(city, car)`, and verify by running `python app.py` and observing the car move around the map every tick without ever appearing on a building or park cell
