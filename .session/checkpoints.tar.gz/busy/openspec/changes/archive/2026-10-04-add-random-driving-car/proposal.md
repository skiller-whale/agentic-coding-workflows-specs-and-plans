# Proposal

## Why

The city map is currently static. A car that drives around at random brings the map to life and is the first step toward a living city simulation.

## What Changes

- Add a `Car` that starts on a random road cell.
- The car moves one road cell at a time, about 4 moves per second.
- At a junction (an intersection where more than one direction is open), the car picks a random direction among the open directions, excluding the one it just came from.
- At a dead end (only one direction open, the one it came from), the car turns back.
- The car never occupies a non-road cell.
- The running app (`app.py`) draws the car as a bright symbol on top of the map and ticks its movement on a timer.

## Capabilities

### New Capabilities
- `car-driving`: A car that starts on a random road cell and drives around the road network indefinitely, moving one cell at a time at a fixed pace, choosing a random open direction at junctions and reversing only at dead ends.

### Modified Capabilities
(none — the map itself is unchanged; the car is drawn as an overlay in the running app, not a change to how the map is loaded or drawn)

## Impact

- `city.py`: gains a way to enumerate the road neighbours of a cell (needed to decide where the car can move).
- New module for the car's position/direction state and its random-move decision.
- `app.py`: gains a timer tick that moves the car and redraws, and a style entry for the car's symbol.
- `tests/`: new tests for car spawning and movement rules.
