# Tasks

## 1. Job claims on the delivery board

- [x] 1.1 Add a `claimed` set to `DeliveryBoard`, a `claim(job)` method that adds to it, and an `unclaimed_waiting_jobs()` method returning `waiting_jobs()` minus anything in `claimed`; verify with a new test in `tests/test_delivery.py` that a claimed job is excluded from `unclaimed_waiting_jobs()` but still appears in `waiting_jobs()` and `jobs`.
- [x] 1.2 Remove a job from `claimed` wherever it's removed from `self.jobs` (in `_age_jobs()` on expiry, and in `deliver()`), and in `collect()` so a delivered/expired job is never left referenced; verify with tests covering: an expired claimed job no longer appears in `claimed` (so a fresh job on the same building can be claimed independently), and a delivered job likewise leaves `claimed` empty.

## 2. Exclusive targeting in `Car`

- [x] 2.1 Change `Car._pick_target` to score candidates from `jobs_board.unclaimed_waiting_jobs()` instead of `jobs_board.waiting_jobs()`, and call `jobs_board.claim(job)` at the same point `self.target_job` is set; verify with a new test in `tests/test_car.py`: given two `Car`s sharing one `DeliveryBoard` with a single waiting job, after the first car targets it, the second car's `_pick_target()` returns `False` and it falls back to driving at random.
- [x] 2.2 Verify the existing single-car scenarios in `tests/test_car.py` (nearest-job targeting, tie-breaking, commit-and-reroute on expiry) still pass unchanged, since a lone car's own claim never excludes itself.

## 3. Fleet wiring in the app

- [x] 3.1 Add a `FLEET_SIZE = 5` constant and a `CAR_STYLES` list of 5 distinct "bold `<colour>` on grey30" styles (yellow, magenta, cyan, white, red) to `app.py`, replacing the single `CAR_STYLE` constant.
- [x] 3.2 Change `CityApp.__init__` to build `self.cars = [Car(self.city, self.jobs_board) for _ in range(FLEET_SIZE)]` instead of a single `self.car`, and change `drive()` to call `.move()` on every car in `self.cars`.
- [x] 3.3 Change `draw()` to accept a list of cars (paired with `CAR_STYLES` by index) instead of a single optional `car`, drawing each car's `●` at its own cell in its own colour, in list order; verify with updated tests in `tests/test_app.py` covering: all 5 cars appear in their assigned colours, and two cars on the same cell render without error (the later one in list order showing on top).
- [x] 3.4 Update `compose()` and `redraw()` to pass `self.cars` to `draw()`; verify by running `python app.py` and confirming 5 differently-colored cars move independently on the map, with takings still shown as a single total beneath it.

## 4. Full-suite check

- [x] 4.1 Run `python -m pytest` and verify the full suite passes, including the updated and new tests from groups 1-3.
