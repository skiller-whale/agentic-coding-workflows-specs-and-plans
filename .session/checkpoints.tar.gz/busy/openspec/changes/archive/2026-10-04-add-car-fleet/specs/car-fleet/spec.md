# Spec Delta

## Purpose

Describes the city as home to a small fleet of cars rather than a single car: how many there are, how they're told apart on the map, and how they share the road without colliding.

## ADDED Requirements

### Requirement: The city runs a fixed-size fleet of cars
The app SHALL create and drive 5 cars at once, each operating independently: each one drives, wanders and pursues delivery jobs using the same rules as any single car, sharing the same city and the same delivery job board.

#### Scenario: Five cars on the map
- **WHEN** someone runs `python app.py`
- **THEN** 5 cars appear on the map, each moving independently

### Requirement: Each car is drawn in its own distinct colour
While the app is running, each of the 5 cars SHALL be drawn in a colour distinct from every other car's, so the fleet remains visually distinguishable on the map at all times.

#### Scenario: Telling cars apart
- **WHEN** someone runs `python app.py`
- **THEN** each of the 5 cars is rendered in a different colour from the other 4

### Requirement: Cars do not avoid or collide with each other
Cars SHALL NOT detect, avoid, or otherwise react to each other's positions. Two or more cars MAY occupy the same road cell at the same time, and this SHALL have no effect on either car's movement, targeting, or delivery of jobs.

#### Scenario: Two cars share a cell
- **WHEN** two cars' independent movement brings them to the same road cell at the same time
- **THEN** both cars remain there or move on exactly as they would have if alone, with no collision, blocking, or diversion
