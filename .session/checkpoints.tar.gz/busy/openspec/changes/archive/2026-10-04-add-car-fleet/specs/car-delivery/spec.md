# Spec Delta

## MODIFIED Requirements

### Requirement: Target the nearest waiting job
Whenever the car is not carrying a package and has no committed pickup target, and at least one delivery job is waiting and not already targeted by another car, the car SHALL select as its target the such job whose pickup building has the shortest route along the roads from the car's current cell, measured in road cells to the nearest road cell adjacent to that building. If more than one such job ties for the shortest route, the car SHALL choose uniformly at random among the tied jobs. Once a car targets a job, no other car SHALL target that same job while it remains that car's committed target.

#### Scenario: One waiting job
- **WHEN** exactly one delivery job is waiting and the car has no target
- **THEN** the car targets that job's pickup building

#### Scenario: Several waiting jobs at different distances
- **WHEN** more than one delivery job is waiting and the car has no target
- **THEN** the car targets the waiting job whose pickup building has the shortest road route from the car's current cell

#### Scenario: A tie for nearest
- **WHEN** two or more waiting jobs' pickup buildings have an equally short road route from the car's current cell, and that route is no longer than any other waiting job's
- **THEN** the car targets one of those tied jobs, chosen at random

#### Scenario: A job already targeted by another car is skipped
- **WHEN** a delivery job is already another car's committed target, and it is the nearest waiting job to a second, idle car
- **THEN** the second car does not target that job, and instead targets the nearest waiting job not already targeted by any car, or drives at random if no such job is waiting
