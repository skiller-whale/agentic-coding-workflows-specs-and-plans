# Proposal

## Why

The city currently has exactly one car. A single car makes a small, lively map feel static once its one job at a time is done — five cars moving independently give the city a constant sense of activity and let more delivery jobs be worked at once.

## What Changes

- The app creates a fleet of 5 cars instead of 1, each driving, wandering and delivering independently using the existing per-car logic.
- A waiting job becomes unavailable to every other car the moment any car in the fleet targets it, so two cars never converge on the same pickup. The job stays off-limits until that car delivers it, or abandons it because it expired before pickup — at which point it's open to be targeted again like any other waiting job.
- Cars are not aware of each other's positions: two cars may occupy the same road cell at the same time, and neither one avoids or reacts to the other.
- Each car is drawn in its own distinct colour, so the five are visually distinguishable on the map.
- Takings remain a single running total for the whole fleet, exactly as today — delivering a job adds its payout to the one shared total regardless of which car delivered it.

## Capabilities

### New Capabilities
- `car-fleet`: the app runs a fixed-size fleet of independently-driving cars that share the city and job board, each rendered in its own distinct colour, with no collision handling between them.

### Modified Capabilities
- `car-delivery`: the job-targeting requirement is extended so a job can be targeted by at most one car in the fleet at a time, instead of assuming a single car with exclusive access to every waiting job.

## Impact

- `app.py`: instantiate a fleet of `Car` instances instead of one; `draw()` renders all of them, each in its assigned colour.
- `car.py`: targeting logic needs to see and respect jobs already claimed by other cars.
- `delivery.py`: `DeliveryBoard` needs a way to track which waiting jobs are currently claimed, and to release a claim when its car abandons it (expiry before pickup) or delivers it.
- Existing tests in `tests/test_app.py`, `tests/test_car.py` and `tests/test_delivery.py` that assume a single car will need updating or extending for a multi-car fleet.
- No change to `car-driving`, `delivery-jobs`, `takings`, or `city-map` capabilities — job spawn/expiry rules, the city map, and the takings total are unaffected.
