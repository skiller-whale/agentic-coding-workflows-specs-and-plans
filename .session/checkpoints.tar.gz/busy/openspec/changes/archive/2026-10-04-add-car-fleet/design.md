# Design

## Context

Today `CityApp` owns a single `Car`, and `Car._pick_target` chooses freely among every job `DeliveryBoard.waiting_jobs()` returns — nothing records that a job has been "spoken for." With one car that's harmless; with several, two idle cars can independently target the same waiting job in the same tick, since targeting doesn't touch the board at all (`jobs_board.collect(job)` only runs once a car physically arrives). See proposal.md for why a fleet of 5 is wanted; this covers how targeting stays exclusive and how the fleet is wired up.

## Goals / Non-Goals

**Goals:**
- Make "targeted by a car" a fact the `DeliveryBoard` can answer, so any car's targeting decision can exclude jobs other cars already claimed.
- Wire `CityApp` to a fixed fleet of 5 independently-moving, independently-colored cars with minimal change to `Car`'s own per-instance logic.

**Non-Goals:**
- Scaling job supply (`MAX_WAITING_JOBS`, spawn interval) for a larger fleet. Five cars competing over a cap of 3 waiting jobs means cars will often find nothing unclaimed and wander — that's the existing, already-specified `car-delivery`/`car-driving` wandering behavior, not a bug introduced here. Left for a later change if the fleet feels too idle in practice.
- Any coordination between cars beyond job-claim exclusivity (no collision avoidance, no load balancing, no awareness of siblings' positions).
- Configurable fleet size. 5 is a fixed constant, same way `MAX_WAITING_JOBS` is today.

## Decisions

**Claim state lives on `DeliveryBoard`, not on `Car` or a new coordinator.** Cars already only ever interact with jobs through `jobs_board` (`waiting_jobs()`, `collect()`, `deliver()`); adding claim-tracking there keeps `Car` instances mutually unaware of each other (no references between cars, no new coordinator object), while still giving every car's `_pick_target` a single shared source of truth to check.

Concretely: `DeliveryBoard` gains a `claimed` set of job objects (identity-based — `DeliveryJob` has no id field and doesn't need one, since Python set membership for plain objects is already by identity) and:
- `unclaimed_waiting_jobs()` — like `waiting_jobs()`, but excluding anything in `claimed`. `Car._pick_target` scores candidates from this instead of `waiting_jobs()`.
- `claim(job)` — called once, right when a car commits to a target (same moment `self.target_job = job` is set today).

Claims are released where jobs already leave the board, so there's one lifecycle to reason about rather than two:
- In `_age_jobs()`, when an uncollected job expires and is dropped from `self.jobs`, it's also dropped from `claimed`.
- In `deliver(job)`, when a delivered job is removed from `self.jobs`, it's also dropped from `claimed`.

A collected-but-not-yet-delivered job needs no claim bookkeeping at all: `waiting_jobs()` (and so `unclaimed_waiting_jobs()`) already excludes anything with `collected = True`, so it's unreachable for new targeting regardless of `claimed`.

**Alternative considered**: give each `Car` a reference to the full fleet and have `_pick_target` scan siblings' `target_job` attributes directly. Rejected — it couples every car to the list of all cars for no benefit over a shared board, and duplicates (via a scan) information the board can just hold once.

**Fleet wiring in `app.py`**: a module-level `FLEET_SIZE = 5` constant; `CityApp.__init__` builds `self.cars = [Car(self.city, self.jobs_board) for _ in range(FLEET_SIZE)]`; `drive()` calls `.move()` on each. `draw()` takes the list of cars paired with their assigned colours and draws each car's `●` in turn, in list order — if two cars share a cell, whichever is drawn last simply shows on top that frame, with no other effect (matches the `car-fleet` "no collision" requirement).

**Colour assignment**: a fixed, parallel list `CAR_STYLES` of 5 "bold `<colour>` on grey30" styles, zipped with `self.cars` by index (position in the list is the car's permanent colour for the run). Chosen to each read clearly against the grey30 road and not collide with the existing palette (`dark_orange` pickup, `deep_sky_blue3` destination, `green`/`dark_green` park, `tan` building): yellow (today's existing car colour), magenta, cyan, white, red.

**Claim order within a tick**: `drive()` moves cars in a fixed list order, so if two idle cars would otherwise tie for the same nearest unclaimed job in the same tick, whichever car is earlier in `self.cars` claims it first and the later one re-evaluates against what's left. This is a deterministic tie-break by fleet position, layered on top of the existing random tie-break among equal-distance jobs — not called out as a spec requirement since no scenario depends on fleet ordering, just noted here as the mechanism.

## Risks / Trade-offs

- [With the job cap left at 3, most of a 5-car fleet may sit idle/wandering most of the time] → Accepted per Non-Goals; existing wander behavior handles it without any new code, and job-supply tuning can follow as its own change if it reads as too idle once running.
- [Multiple cars on one cell are visually ambiguous for that frame] → Accepted; explicitly spec'd as no-collision-handling in `car-fleet`, and resolves itself as soon as either car moves on.
- [Claims never cleaned up would leak unbounded references over a long run] → Mitigated by releasing claims in the same two places jobs are otherwise removed from `self.jobs` (`_age_jobs`, `deliver`), so there's no separate cleanup path to forget.
