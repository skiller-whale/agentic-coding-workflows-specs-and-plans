# Proposal

## Why

The city has grown from a single wandering car to a fleet running paid deliveries, but every junction still behaves identically - there is no sense of traffic control. Giving a handful of junctions working traffic lights adds a visible, understandable rule cars must obey, making the simulation read less like free-roaming dots and more like an actual city.

## What Changes

- Four junctions, one per quadrant of the map, get a traffic light that cycles every 3 seconds between north-south green and east-west green.
- A car approaching a lit junction waits at the cell before it while its direction of travel is red, and proceeds once its direction turns green. This applies whether the car is wandering, pursuing a pickup, or carrying a delivery.
- Each lit junction is drawn on the map in red or green according to its current phase.
- Routing (shortest-path selection) and delivery payouts are unaffected - lights add waiting time but do not change distances or prices.

## Capabilities

### New Capabilities
- `traffic-lights`: placement of traffic lights on a subset of junctions, their red/green phase cycling over time, and their on-map rendering.

### Modified Capabilities
- `car-driving`: adds the requirement that a car waits at a red light rather than entering a lit junction against it, cross-referencing `traffic-lights` the same way existing driving requirements already cross-reference `car-delivery`.

## Impact

- `city.py`: needs a way to identify 4-way junction cells so lights can be placed on them.
- `car.py`: movement (both random wandering and route-following) must check a light before entering a lit junction cell, and hold position while red.
- `app.py`: must create and tick a traffic-lights component alongside the existing drive/job loops, pass it to each car, and draw each lit junction in its current colour.
- New module for the traffic-lights capability (junction selection, phase timing, colour lookup).
- Tests: new coverage for junction selection and phase cycling, car waiting behaviour, and the map rendering of lit junctions.
