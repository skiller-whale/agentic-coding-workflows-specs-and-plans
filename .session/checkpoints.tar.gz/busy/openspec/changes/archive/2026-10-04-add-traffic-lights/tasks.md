# Tasks

## 1. Junction selection

- [x] 1.1 Add a way to list 4-way junction cells (road cells with all 4 orthogonal neighbours as road) to `city.py`, and verify with a test on a small synthetic map (mix of 4-way, 3-way and dead-end cells) that only the true 4-way cells are returned
- [x] 1.2 Add a function that picks 4 junctions spread across the map (one per quadrant of the bounding box, nearest to each quadrant's centre, deterministic tie-break), and verify with a test on a small synthetic map with several eligible junctions that exactly one is chosen per quadrant
- [x] 1.3 Verify on the real `city_map.txt` (via `City.load()`) that exactly four junctions are selected and each falls in a different quadrant

## 2. Traffic light phase cycling

- [x] 2.1 Create `traffic_lights.py` with a `TrafficLights` class that takes a city (or junction list) and exposes the chosen junctions, a shared phase (`"ns"` or `"ew"`, starting `"ns"`), and a `tick()` method; verify with a test that the phase stays the same for 2 ticks and flips on the 3rd
- [x] 2.2 Add an `is_green(cell, axis)` method (axis is `"ns"` or `"ew"`) that returns `True` for any cell not in the chosen junctions, and otherwise reflects the current phase; verify with tests covering an unlit cell, a lit cell on the green axis, and a lit cell on the red axis
- [x] 2.3 Verify with a test that phase keeps alternating correctly across many ticks (e.g. 20 phase switches)

## 3. Cars wait at red lights

- [x] 3.1 Add an optional `traffic_lights=None` parameter to `Car.__init__`, defaulting to no lights (never blocks), and verify existing `tests/test_car.py` tests still pass unchanged
- [x] 3.2 Add a light check shared by both movement paths: before moving into a cell, if it's a lit junction and the light is red for the axis of travel (vertical move = north-south, horizontal move = east-west), do not move this tick
- [x] 3.3 Change `_advance_route` to peek at `self.route[0]` and only pop and move when the light allows it, leaving the route untouched while waiting; verify with a test that a car following a route holds position for the red ticks and then proceeds without skipping a cell
- [x] 3.4 Change `_random_move` to remember its chosen next cell (new `self._waiting_cell`) and hold it across ticks until the light allows the move, rather than re-choosing a direction each tick; verify with a test that a wandering car waits at a red light and then moves into the junction on green, still excluding its previous cell
- [x] 3.5 Verify with a test that a car on a lit junction cell is not blocked from moving off it (the light only blocks entry)

## 4. Drawing lit junctions

- [x] 4.1 Add a `traffic_lights=None` parameter to `app.py`'s `draw()`, rendering each junction in `traffic_lights.junctions` in a colour for the `"ns"` phase and a different colour for the `"ew"` phase, and verify with a test (using `style_at`, as in existing `tests/test_app.py` tests) that the two phases render distinct styles at a junction cell
- [x] 4.2 Verify with a test that a car occupying a lit junction cell is still drawn on top of the light (car style wins)
- [x] 4.3 Verify with a test that only the four junction cells' styles change between an all-green-phase render and an all-red-phase render of the same map

## 5. Wire it into the running app

- [x] 5.1 Create a `TrafficLights` instance in `CityApp.__init__`, pass it to every `Car`, and add a `set_interval(1, self.tick_lights)` loop that ticks it and redraws, matching the existing `tick_jobs` pattern
- [x] 5.2 Run the full test suite (`python -m pytest`) and verify it passes
- [x] 5.3 Run `python app.py` and verify by eye: four junctions show a red or green light, a car visibly stops before a red light and crosses once it turns green, and nothing else in the map's appearance or the delivery flow has changed
