# Spec Delta

## ADDED Requirements

### Requirement: Wait at a red light before entering a lit junction
Before moving onto a cell that is a lit junction (see `traffic-lights`), the car SHALL check whether the light is green for its direction of travel. If red, the car SHALL NOT move this tick and SHALL instead retry the same move on its next tick; it SHALL move onto the junction once the light turns green. This applies regardless of whether the car is wandering, pursuing a pickup, or carrying a delivery.

#### Scenario: Waiting at a red light
- **WHEN** the car's next move would enter a lit junction and the light is red for its direction of travel
- **THEN** the car's position does not change this tick

#### Scenario: Proceeding on green
- **WHEN** the car's next move would enter a lit junction and the light is green for its direction of travel
- **THEN** the car moves onto the junction cell as normal

#### Scenario: A waiting car still proceeds once the light turns green
- **WHEN** the car has waited at a red light and the light then turns green for its direction of travel
- **THEN** the car moves onto the junction cell on its next move, without re-choosing a different direction
