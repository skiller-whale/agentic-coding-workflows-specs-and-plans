# Design

## Context

The road network is implicit in the grid: `City.road_neighbors` just returns whichever of the 4 orthogonal cells are road, with no notion of "junction" anywhere in the code. `Car.move()` always completes a move the instant it decides on a direction - there is no "waiting" state today, for wandering (`_random_move`) or for route-following (`_advance_route`). `app.py` already runs two independent `set_interval` loops at different cadences: `drive` at 4/sec (car movement) and `tick_jobs` at 1/sec (job spawn/expiry, driven by `DeliveryBoard.tick()`'s own tick counter). See proposal.md - Why/What Changes for the feature itself.

## Goals / Non-Goals

**Goals:**
- Identify true 4-way junctions generically, so light placement works on any map shape, not just today's fixed `city_map.txt`.
- Make waiting at a red light a small, local change to `car.py`'s existing movement paths rather than a new car state machine.
- Keep the phase clock's cadence independent of both the car's 4/sec move rate and the job board's tick counter, so each concern stays owned by its own loop.

**Non-Goals:**
- Collision or right-of-way between cars. The sim already tolerates multiple cars on one cell (`app.py`'s draw() layering, `test_two_cars_sharing_a_cell_draw_without_error`); lights don't change that.
- Any change to routing or payouts. `City`'s BFS is a shortest-path-by-cell-count search over the road graph; lights add wait time on top of a route, they don't change which route is shortest or what it costs. `delivery.py`'s payout formula is untouched.
- Modelling a junction's four independent signal faces. One glyph per lit junction shows the current phase as a whole (see Decisions).

## Decisions

### Junction eligibility: exactly 4 open directions
A junction eligible for a light is a road cell where all 4 orthogonal neighbours are road. This sidesteps 3-way/corner junctions, where "north-south vs east-west" doesn't cleanly apply, and gives every light exactly two opposing approach pairs.

Alternative considered: include 3-way junctions with a light that's simply "one approach always red." Rejected - it complicates axis logic for a case the current map barely has at its edges, for no requested benefit.

### Choosing which four junctions
Split the city's bounding box into a 2x2 grid of quadrants; in each quadrant, pick the eligible junction closest to that quadrant's centre (Manhattan distance, ties broken by scan order). This is deterministic, needs no magic coordinates tied to the current map's dimensions, and satisfies "spread across the map" directly.

Alternative considered: hardcode the four `(x, y)` cells for today's specific `city_map.txt`. Rejected - it breaks silently the moment the map changes, and the computed approach is barely more code.

### Phase clock: its own 1/sec tick, independent of car movement
A `TrafficLights` component owns a single shared phase (`"ns"` or `"ew"`) for all lit junctions, flipping every 3 ticks. It's ticked once per second from a new `set_interval(1, self.tick_lights)` in `app.py`, mirroring the existing `tick_jobs` loop but kept separate since it's a distinct concern. Cars read whatever phase is current at their own 4/sec move rate - the two loops don't need to be in step, since the car only ever asks "is it green right now?".

Alternative considered: tick the lights once per `drive()` call (4/sec) and count 12 ticks per phase. Rejected - it ties a wall-clock concept ("3 seconds") to the car's move rate, so changing one would silently change the other.

Alternative considered: independent phase/offset per light. The proposal says "each light switches every three seconds" without asking for staggered timing, so one shared phase for all four lights is the simpler reading and is called out here as the resolved interpretation, not deferred.

### Car waiting: commit to a next cell, then hold until green
- Route-following (`_advance_route`, used for both pickup and delivery legs) already commits to a direction via `self.route[0]`. Changing it from pop-then-move to peek-then-check-then-pop-and-move gives "wait in place, retry next tick" for free, with no new state.
- Wandering (`_random_move`) picks a fresh direction each call today. To get the same commit-and-wait behaviour (rather than re-rolling a different direction every tick while stopped), it now remembers the chosen next cell in a new `self._waiting_cell` attribute until the car actually moves into it.
- Either way, the check is the same: before moving into a cell, if that cell is a lit junction and the light is red for the axis of travel (north-south movement vs east-south movement... i.e. vertical vs horizontal), the car does not move this tick. Once the car is on the junction cell (having entered on green), no further light check applies to leaving it.
- `Car` takes the `TrafficLights` instance as a new constructor parameter, defaulting to `None` (meaning "no lights, never blocks"). This keeps every existing `Car(city, board, random=...)` call site and test working unchanged.

Alternative considered: re-derive the wandering car's direction choice every tick, including while blocked. Rejected - with a red-blocked candidate among several open directions, this would make the car silently take a different street instead of visibly waiting, which doesn't match "a car waits at a red light."

### Drawing: one glyph per lit junction, colour follows the shared phase
`draw()` gains a `traffic_lights` parameter. For every cell in `traffic_lights.junctions`, it looks up the current phase and renders a green glyph when the phase is `"ns"` and red when `"ew"` - i.e. the glyph shows which axis currently has right of way, not two independent light faces. A car on top of a light cell is drawn on top of it, consistent with the existing car-over-everything precedence.

## Risks / Trade-offs

- [Single shared phase for all four lights looks synchronized/artificial next to real intersections, which stagger] → Acceptable for this sim; proposal didn't ask for staggering, and it's a single config change later (per-light phase offset) if wanted.
- [A car can wait indefinitely in principle if stuck behind a red light while also being a delivery car - this could make a route take longer than its payout assumed] → Not a new risk introduced here: non-goal above already excludes payout rework, and wait times are small (at most one 3-second phase) relative to job lifetimes (15 ticks).
- [Adding a 5th `set_interval` loop in `app.py` (now drive, tick_jobs, tick_lights) could redraw three times redundantly per second] → Acceptable; `redraw()` is cheap (rebuilds a `Text` from the grid) and this matches the existing `tick_jobs` pattern exactly.
