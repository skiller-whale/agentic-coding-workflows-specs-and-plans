# Tasks

## 1. Building identification in City

- [x] 1.1 Add building grouping to `city.py`: flood fill contiguous `BUILDING` cells at load time into a list of buildings (each a frozenset of `(x, y)` cells), exposed from `City`; verify with `python -m pytest tests/test_city.py`.
- [x] 1.2 Add tests to `tests/test_city.py` covering: every building cell belongs to exactly one building; road and park cells belong to none; and a small synthetic multi-cell building (via a `City([...])` literal, as `test_car.py` already does for its junction/corridor maps) groups into exactly one building; verify `python -m pytest tests/test_city.py` passes.

## 2. Delivery job board

- [x] 2.1 Create a new module with a delivery-board class: a tick-based `tick()` method that attempts one spawn every 3 ticks (skipped if 3 jobs are already waiting or fewer than 2 buildings are free), and ages each waiting job out after 15 ticks; accept an injectable `random` (default the `random` module), following `Car`'s `random=random_module` pattern.
- [x] 2.2 Add `tests/test_delivery.py` using a seeded `random.Random` and small synthetic `City` maps, covering: a spawned job's pickup and destination are different buildings; no spawn occurs once 3 jobs are waiting; no spawn occurs when fewer than 2 buildings are free; a building already in a waiting job is never chosen for another job; and a job is removed (freeing its buildings) exactly 15 ticks after it spawned; verify `python -m pytest tests/test_delivery.py` passes.

## 3. Rendering and app wiring

- [x] 3.1 Extend `draw()` in `app.py` to take the current waiting jobs and override each pickup building's and destination building's cell styles with their own distinct Rich styles (applied after the base `CELL_STYLES` lookup, before the car is drawn on top); verify with new assertions in `tests/test_app.py` that a pickup building's cells render differently from a plain building and from a destination building's cells.
- [x] 3.2 Wire the delivery board into `CityApp` in `app.py`: construct it alongside `Car`, drive it from its own `set_interval(1, ...)` tick (separate from the car's `1/4`-second interval), and pass its current jobs into `draw()` on every redraw.
- [x] 3.3 Add a test to `tests/test_app.py` asserting that, with jobs active, only the cells belonging to pickup/destination buildings differ from the plain map render (mirroring the existing `test_only_the_cars_cell_changes` pattern); verify `python -m pytest tests/test_app.py` passes.

## 4. Full verification

- [x] 4.1 Run `python -m pytest` and verify the full suite passes with no regressions.
- [x] 4.2 Run `python app.py` and observe, over roughly a minute: jobs appearing every few seconds up to 3 at once, pickup and destination buildings each in their own distinct colour, and old jobs expiring and freeing their buildings for reuse - matching the `delivery-jobs` spec scenarios.
