# Design

## Context

See proposal.md - Why. Relevant current state:

- `City` (`city.py`) only tracks cell *type* (`ROAD`/`BUILDING`/`PARK`) per `(x, y)`; it has no notion of a building as a group of cells.
- `city_map.txt` lays buildings out as contiguous blocks of `#` cells (commonly 2x2 in the current map, but nothing guarantees that shape for a future map).
- `Car` (`car.py`) is the existing precedent for app-level randomness and timing: it takes an injectable `random` for deterministic tests, and `app.py` drives it from a `set_interval` tick rather than real time.
- `app.py` draws the grid once per cell from a static `CELL_STYLES` lookup, then overlays the car's own style on its cell.

## Goals / Non-Goals

**Goals:**
- Give `City` a general way to address "a building" as a whole, not tied to any particular building shape or size.
- Drive job spawn/expiry off an injectable, testable clock rather than wall-clock time, matching the `Car` precedent.
- Keep delivery-job state and city-map state decoupled from rendering: `app.py` reads state and draws; it does not own job logic.

**Non-Goals:**
- No car/job interaction (the car does not pick up or deliver anything). That's explicitly future scope per proposal.md.
- No persistence of jobs across app restarts.
- No configurability (cap, spawn interval, expiry duration) beyond constants in code.

## Decisions

**Building identification: flood fill over `BUILDING` cells, computed once at load.**
Add a `buildings()` (or equivalent) method/property to `City` that scans the grid once and groups orthogonally-connected `BUILDING` cells via flood fill into a list of buildings, each holding its frozenset of `(x, y)` cells. Alternative considered: assume a fixed 2x2 block stride (true of today's `city_map.txt`) and derive buildings from grid arithmetic. Rejected because it silently breaks for any future map with irregularly-shaped or differently-sized buildings, and `city-map`'s existing spec makes no such shape guarantee - flood fill works for any map satisfying the existing `city-map` spec.

**Job timing: tick-based, not wall-clock.**
A `DeliveryBoard` (name indicative) exposes a `tick()` method with no time argument. `app.py` calls it once per second via its own `set_interval(1, ...)`, separate from the car's `1/4`-second interval. Internally the board counts ticks: it attempts one spawn every 3 ticks (if under the cap of 3 and at least 2 buildings are free), and each job carries a remaining-ticks counter that starts at 15 and is removed at 0. Alternative considered: store wall-clock spawn timestamps and compare to `time.monotonic()` at draw time. Rejected because it makes tests depend on real sleeps or monkeypatched clocks; a plain tick counter lets tests call `tick()` directly and assert exact outcomes, exactly as `test_car.py` calls `move()` directly without waiting on `set_interval`.

**Randomness: injectable `random`, like `Car`.**
`DeliveryBoard.__init__` accepts a `random` module/instance (default `random` module) so tests can seed it, following `Car`'s existing `random=random_module` pattern.

**Job/building bookkeeping: track busy buildings as a set.**
The board tracks which buildings are currently assigned (as a pickup or destination) to a waiting job. Spawning a job samples 2 distinct buildings from `all_buildings - busy_buildings`; if fewer than 2 are free, the spawn attempt is skipped for that tick (per the `delivery-jobs` spec's "no new job" scenario) and retried on the next scheduled attempt.

**Rendering: a lookup from cell to highlight style, applied after base cell style and before the car.**
`app.py`'s `draw()` gains a step that, for each active job, looks up its pickup and destination buildings' cells and overrides their style with a pickup or destination style - the same "replace this cell's style" pattern already used for the car, just keyed by a set of cells instead of one `(x, y)`. The car is drawn last (cars only ever sit on road cells, so there's no real overlap with building highlights, but keeping the existing draw order avoids any ambiguity). Exact Rich style strings for the two highlight colours are an implementation detail chosen to read clearly against the existing building colour (`tan on grey19`) and each other; they are not fixed here.

## Risks / Trade-offs

- [Tick-based timing is only approximately real-time (drift if a tick is delayed)] -> Acceptable for a visual/ambient feature with no gameplay stakes riding on exact timing; matches the precision level of the existing "about 4 times per second" car requirement.
- [Flood fill runs at load time over the whole grid] -> City maps here are small (tens of cells); negligible cost, and it only runs once per `City.load()`, not per frame.
- [A map with fewer than 2 buildings, or where available buildings keep being exhausted, could leave the board stuck at fewer than 3 jobs] -> Already the specified behavior (spawn attempts simply skip when free buildings are short), not a bug to fix here.
