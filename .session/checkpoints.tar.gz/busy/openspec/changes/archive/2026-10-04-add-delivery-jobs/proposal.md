# Proposal

## Why

The city currently has a car wandering its roads with nothing to do. Delivery jobs give the map a sense of ongoing activity by marking which buildings have a package waiting and which need one, independent of whether anything yet acts on that information.

## What Changes

- Introduce delivery jobs: each job pairs a pickup building with a different destination building, both chosen at random.
- Jobs appear automatically every few seconds while the app runs, up to a cap of 3 jobs waiting at once.
- A building holds at most one role (pickup or destination) in at most one job at a time; it is not reused by another job until free.
- Jobs expire after a fixed time if nothing clears them sooner, freeing their buildings so new jobs can appear. (No pickup/delivery interaction exists yet — see Impact.)
- Pickup buildings and destination buildings are each highlighted with their own distinct colour on the map, on top of the existing building styling.
- The city grid gains a notion of individual buildings (contiguous blocks of building cells), since today it only tracks cell type, not building identity — needed to address "a building" as a whole rather than one cell.

## Capabilities

### New Capabilities
- `delivery-jobs`: the lifecycle of delivery jobs (spawning, pairing pickup/destination buildings, the waiting cap, expiry) and how pickup/destination buildings are drawn.

### Modified Capabilities
- `city-map`: adds a requirement that the map data exposes individual buildings (contiguous groups of building cells), not just per-cell type, so other capabilities can address "a building" as a whole. Existing fixed-map and draw-every-cell requirements are unchanged.

## Impact

- `city.py`: add building identification (grouping contiguous `BUILDING` cells into addressable buildings).
- New module for delivery job state (job list, spawn/expiry timing, random pickup/destination selection avoiding reuse of busy buildings).
- `app.py`: draw pickup/destination highlights over the relevant building cells, and drive the spawn/expiry timer alongside the existing car-movement timer.
- No change to car behavior: the car keeps wandering at random, unaware of jobs. Any future "car actually delivers packages" mechanic is out of scope for this change.
