# Spec Delta

## Purpose

Delivery jobs mark which buildings currently have a package waiting to be picked up and which need one delivered, giving the city a sense of ongoing activity independent of the car.

## ADDED Requirements

### Requirement: Jobs spawn automatically over time
Every 3 seconds while the app is running, the system SHALL spawn one new delivery job if fewer than 3 jobs are currently waiting and at least two buildings are free (not already part of a waiting job).

#### Scenario: A new job appears when below the cap
- **WHEN** fewer than 3 jobs are waiting and at least two buildings are free
- **THEN** a new delivery job is spawned at the next 3-second spawn tick

#### Scenario: No new job appears at the cap
- **WHEN** 3 jobs are already waiting
- **THEN** no new delivery job is spawned, even if free buildings remain

### Requirement: A job pairs two distinct random buildings
Each delivery job SHALL have a pickup building and a destination building, both chosen uniformly at random from the buildings currently free, with the destination distinct from the pickup.

#### Scenario: Pickup and destination are never the same building
- **WHEN** a delivery job is spawned
- **THEN** its pickup building and destination building are different buildings

### Requirement: A building serves at most one job at a time
A building SHALL be the pickup or destination of at most one waiting job at a time; it SHALL NOT be assigned to another job until its current job ends.

#### Scenario: A busy building is not reused
- **WHEN** a building is already the pickup or destination of a waiting job
- **THEN** that building is not chosen as the pickup or destination of any other job while the first job is still waiting

### Requirement: Jobs expire after a fixed time
A delivery job SHALL expire and be removed 15 seconds after it was spawned, freeing its pickup and destination buildings so they may be chosen by a later job.

#### Scenario: An old job is cleared
- **WHEN** a delivery job has been waiting for 15 seconds
- **THEN** it is removed, and its pickup and destination buildings are no longer highlighted

### Requirement: Pickup and destination buildings are highlighted distinctly
While a delivery job is waiting, the system SHALL draw its pickup building and its destination building each in their own distinct colour, on top of the ordinary building styling.

#### Scenario: A pickup building looks different from a destination building
- **WHEN** a delivery job is waiting
- **THEN** its pickup building's cells are drawn in the pickup colour and its destination building's cells are drawn in a different, destination colour

#### Scenario: Highlights disappear when a job ends
- **WHEN** a delivery job expires
- **THEN** its former pickup and destination buildings return to the ordinary building styling, unless still part of another waiting job
