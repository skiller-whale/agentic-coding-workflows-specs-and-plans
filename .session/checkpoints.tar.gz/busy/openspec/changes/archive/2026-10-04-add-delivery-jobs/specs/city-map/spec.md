# Spec Delta

## ADDED Requirements

### Requirement: Buildings are identified as groups of cells
The city's map data SHALL group orthogonally-contiguous building cells into individual buildings, so a building can be addressed as a whole rather than as individual cells.

#### Scenario: A multi-cell building is one building
- **WHEN** the map is loaded
- **THEN** each maximal orthogonally-connected group of building cells forms exactly one building, separate from every other such group

#### Scenario: Building cells belong to exactly one building
- **WHEN** the map is loaded
- **THEN** every building cell belongs to exactly one building, and no road or park cell belongs to any building

### Requirement: All buildings are enumerable
The city SHALL expose the full list of identified buildings so other capabilities can select among them.

#### Scenario: Every building is included
- **WHEN** the map is loaded
- **THEN** the list of buildings includes every building cell group in the map, and no building appears more than once
