# Design

## Context

See proposal.md - Why. Relevant current state:

- `Car` (`car.py`) only knows about `City`: it picks a uniformly random open neighbour each move, tracking `prev` to avoid immediate reversal. It has no notion of a goal.
- `City` (`city.py`) exposes `road_neighbors(x, y)` (open adjacent road cells) and `all_road_cells()`, enough to build a BFS, but has no shortest-path or "cells adjacent to a building" query yet.
- `DeliveryBoard` (`delivery.py`) owns job spawn/expiry on its own tick, independent of the car. `DeliveryJob` currently has only `pickup`, `destination`, and `ticks_remaining`; there is no collected/delivered state.
- `app.py` runs the car on a `1/4`-second interval and the board on a separate `1`-second interval, via two independent `set_interval` calls - they are not synchronized to the same tick.
- All randomness in this codebase is injected (`random=random_module` defaulting to the stdlib module), so tests can pass a seeded `random.Random`. This change follows the same pattern for the one new place randomness appears (tie-breaking among equally-near jobs).

## Goals / Non-Goals

**Goals:**
- Add shortest-route movement without discarding the existing random-walk code path; both coexist in `Car` and are chosen per move.
- Keep `City` as the one place that knows about the road graph; `Car` asks it "what's the shortest route from here to near that building" rather than doing its own graph walk.
- Keep `DeliveryBoard` the sole owner of job lifecycle state (including the new collected/delivered transitions), so `app.py`'s rendering logic stays a straightforward function of `board.jobs`.
- Keep everything driven by explicit calls (`move()`, `tick()`, `collect()`, `deliver()`) rather than wall-clock time, matching the existing testing style.

**Non-Goals:**
- No change to spawn cadence, the 3-job cap size, or the 15-second expiry duration - only to what counts as "waiting" for those rules.
- No visual change to the car itself (e.g. a distinct glyph while carrying a package). Nothing in the proposal asked for it, and it's a separate, purely cosmetic decision that can be layered on later without touching this change's specs.
- No handling for a map where a job's pickup or destination is unreachable from the car's position (e.g. a disconnected road graph). The shipped `city_map.txt` is fully connected (same assumption the original car-driving design already relies on); an unreachable target is out of scope, as it was for the original random-walk dead-end handling.

## Decisions

**Shortest-route query lives on `City`, as `City.route_to_building(start, building)`.**
Implemented as a breadth-first search over `road_neighbors`, starting from `start` and treating every road cell orthogonally adjacent to any cell of `building` as a goal. BFS naturally finds the nearest such goal cell first (unweighted grid, so BFS depth is true road distance), and returns the full cell-by-cell path from `start` to that goal cell (or `None` if unreachable). This keeps `Car` free of graph-walking logic, mirroring how `road_neighbors` already keeps bounds/road-type checks out of `Car`. Both "find the nearest job" (compare path lengths across jobs) and "drive there" (follow the returned path) reuse this one method.
Alternative considered: a generic `shortest_path(start, goal_cell)` plus a separate "cells adjacent to a building" helper, composed by the caller. Rejected as needless ceremony for the only caller `Car` has; `route_to_building` is the one query this change needs.

**`Car` gains explicit state: `self.target_job` and `self.carrying` (bool), plus `self.route` (the remaining planned cells).**
Each `move()` call:
1. If `self.carrying`: if `self.target_job` is no longer in `jobs_board.jobs` this can't happen (collected jobs aren't removed until delivered - see below), so just follow `self.route`; arriving at its end calls `jobs_board.deliver(self.target_job)` and clears `target_job`/`carrying`/`route`.
2. Elif `self.target_job` is set (pursuing a pickup): if the job has expired (no longer in `jobs_board.jobs`), clear it and fall through to re-targeting below. Otherwise follow `self.route`; arriving at its end calls `jobs_board.collect(self.target_job)`, sets `carrying = True`, and recomputes `self.route` via `route_to_building` toward the job's destination.
3. Elif no target: look at `jobs_board.waiting_jobs()` (jobs not yet collected). If any exist, compute `route_to_building` from the car's current cell to each one's pickup, pick the shortest (ties broken via the injected `random`), set it as `target_job`, and set `self.route` to that path.
4. Else: fall back to the existing random-walk logic unchanged.
In every branch, "follow `self.route`" means: pop the next cell off the front, move there, and set `prev` to the cell just left (so a later drop back into random-walk still has a sensible `prev` and the no-immediate-reversal rule behaves correctly).
Alternative considered: have `app.py` mediate - compute targets and call board methods itself, leaving `Car` only a passive path-follower. Rejected because `Car` already owns "decide where to move next" as a self-contained unit (it's unit-tested by calling `move()` directly, with no `app.py` involved); splitting target selection into `app.py` would require `app.py` to duplicate the commit/re-evaluate state machine and break that testing style.

**`Car` takes `jobs_board` as a required second constructor argument: `Car(city, jobs_board, random=random_module)`.**
This is the `**BREAKING**` change called out in the proposal. `app.py` already constructs `self.jobs_board` before `self.car`, so the call site only needs reordering: build the board first, then pass it into `Car`.

**`DeliveryJob` gains a `collected` flag (default `False`); `DeliveryBoard` gains `waiting_jobs()`, `collect(job)`, and `deliver(job)`.**
- `waiting_jobs()` returns `[job for job in self.jobs if not job.collected]` - the set `Car` is allowed to target and the set the spawn cap counts.
- `collect(job)` sets `job.collected = True`. It does not remove the job from `self.jobs` or touch `ticks_remaining`.
- `deliver(job)` removes `job` from `self.jobs` entirely.
- `busy_buildings()` changes to: pickup buildings of `waiting_jobs()`, plus destination buildings of every job in `self.jobs` (waiting or collected) - so a pickup frees the moment it's collected, but a destination stays reserved until delivery.
- `_age_jobs()` changes to only decrement and expire jobs where `not job.collected` - a collected job's `ticks_remaining` is simply left alone (it becomes meaningless once collected, since delivery - not expiry - is what removes the job).
Alternative considered: a three-state `status` enum (`waiting` / `collected` / `delivered`) instead of a boolean plus removal-on-delivery. Rejected as unnecessary - "delivered" and "not in `self.jobs` anymore" are the same thing, so a third state would be redundant with list membership.

**Rendering: `app.py`'s pickup/destination highlight lookup switches on `job.collected`.**
Today it always highlights both `job.pickup` and `job.destination` for every job in the passed-in list. The fix is a one-line condition: only add the pickup highlight when `not job.collected`; always add the destination highlight (for every job still in `board.jobs`, collected or not) until delivery removes it from that list entirely.

## Risks / Trade-offs

- [BFS runs on every re-target, not just once] → Each BFS is over a small map (tens of road cells) and only runs when the car has no current target (i.e., right after a delivery or at startup), not every move - negligible cost at 4 moves/sec.
- [`Car`'s `move()` now has four branches instead of one] → Each branch is small and independently testable by constructing a `Car` in a specific state (`target_job` set, `carrying` set, etc.) the same way `test_car.py` already seeds `car.x`/`car.prev` directly for the dead-end/junction cases.
- [A job could expire on the same tick the car arrives at its pickup, since the car's and board's timers aren't synchronized] → Resolved by ordering: `Car.move()` checks `target_job in jobs_board.jobs` before checking arrival, so if the board's tick already removed it this move, the car re-targets instead of "arriving" at a job that's no longer there. This is a direct consequence of the commit/re-evaluate rule in the `car-delivery` spec, not a special case.
- [Tie-breaking among equally-near jobs adds a second place randomness enters `Car`] → Uses the same injected `random` the car already takes for its walk, so tests can still seed it for deterministic tie-breaks.
