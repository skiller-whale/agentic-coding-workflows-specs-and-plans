# Spec Delta

## MODIFIED Requirements

### Requirement: Jobs spawn automatically over time
Every 3 seconds while the app is running, the system SHALL spawn one new delivery job if fewer than 3 jobs are currently waiting (not yet collected) and at least two buildings are free (not already part of a waiting job as a pickup, or part of any not-yet-delivered job as a destination).

#### Scenario: A new job appears when below the cap
- **WHEN** fewer than 3 jobs are waiting and at least two buildings are free
- **THEN** a new delivery job is spawned at the next 3-second spawn tick

#### Scenario: No new job appears at the cap
- **WHEN** 3 jobs are already waiting
- **THEN** no new delivery job is spawned, even if free buildings remain

#### Scenario: A collected job does not count toward the cap
- **WHEN** a job's package has been collected and 3 other jobs are waiting
- **THEN** that collected job does not count toward the 3-job cap

### Requirement: A building serves at most one job at a time
A building SHALL be the pickup of at most one waiting (not yet collected) job at a time, and the destination of at most one not-yet-delivered job at a time; it SHALL NOT be assigned to another job in that role until it is free.

#### Scenario: A busy building is not reused
- **WHEN** a building is already the pickup of a waiting job or the destination of a not-yet-delivered job
- **THEN** that building is not chosen for the same role in any other job while it remains busy in that role

#### Scenario: A pickup building frees up on collection
- **WHEN** a job's package is collected
- **THEN** its pickup building may immediately be chosen as the pickup or destination of a different job, even though the job itself has not been delivered yet

### Requirement: Jobs expire after a fixed time
A delivery job SHALL expire and be removed 15 seconds after it was spawned if its package has not yet been collected, freeing its pickup and destination buildings so they may be chosen by a later job. A job whose package has already been collected SHALL NOT expire.

#### Scenario: An old job is cleared
- **WHEN** a delivery job has been waiting, with its package not yet collected, for 15 seconds
- **THEN** it is removed, and its pickup and destination buildings are no longer highlighted

#### Scenario: A collected job does not expire
- **WHEN** a job's package was collected more than 15 seconds ago and the job has not yet been delivered
- **THEN** the job is still present, and its destination building is still highlighted

### Requirement: Pickup and destination buildings are highlighted distinctly
While a delivery job is waiting, the system SHALL draw its pickup building and its destination building each in their own distinct colour, on top of the ordinary building styling. Once the job's package is collected, its pickup building's highlight SHALL be removed while its destination building's highlight remains until the job is delivered.

#### Scenario: A pickup building looks different from a destination building
- **WHEN** a delivery job is waiting
- **THEN** its pickup building's cells are drawn in the pickup colour and its destination building's cells are drawn in a different, destination colour

#### Scenario: Highlights disappear when a job ends
- **WHEN** a delivery job expires
- **THEN** its former pickup and destination buildings return to the ordinary building styling, unless still part of another waiting job

#### Scenario: Pickup highlight clears on collection
- **WHEN** a job's package is collected
- **THEN** its pickup building returns to the ordinary building styling, while its destination building keeps the destination highlight

## ADDED Requirements

### Requirement: A job's package can be collected
The system SHALL support marking a waiting job's package as collected. Collecting a job immediately frees its pickup building, clears its pickup highlight, and exempts the job from the waiting-job cap and the expiry timer, while leaving the job otherwise in place until delivered.

#### Scenario: Collecting a job
- **WHEN** a waiting job's package is marked collected
- **THEN** the job remains on the board, its pickup building is free, its pickup highlight is gone, and it is no longer counted as waiting

### Requirement: A collected job is delivered and removed
The system SHALL support marking a collected job as delivered. Delivering a job removes it entirely, freeing its destination building and clearing its destination highlight.

#### Scenario: Delivering a job
- **WHEN** a collected job is marked delivered
- **THEN** the job is removed from the board and its destination building is no longer highlighted
