# Spec Delta

## MODIFIED Requirements

### Requirement: Random direction at a junction, no reversing except at a dead end
While the car has no delivery job to pursue and is not carrying one, each time it moves it SHALL choose uniformly at random among the open directions, where "open" means leading to an adjacent road cell and excluding the direction back to the cell the car just came from. If excluding that direction leaves no open direction (a dead end), the car SHALL reverse back the way it came instead. While pursuing or carrying a delivery job, the car's direction is instead governed by `car-delivery`.

#### Scenario: Choosing among several open directions
- **WHEN** the car has no delivery job to pursue or carry, and is at a cell where more than one direction (other than the way it came) is open
- **THEN** the car moves to one of those open cells, chosen at random, and never to the cell it just came from

#### Scenario: Continuing through a cell with one open direction
- **WHEN** the car has no delivery job to pursue or carry, and is at a cell where exactly one direction (other than the way it came) is open
- **THEN** the car moves to that cell

#### Scenario: Reversing at a dead end
- **WHEN** the car has no delivery job to pursue or carry, and is at a cell where no direction is open except the way it came
- **THEN** the car moves back to the cell it just came from
