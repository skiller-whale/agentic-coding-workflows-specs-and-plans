# Proposal

## Why

The car wanders the roads at random and delivery jobs appear and expire on their own timer, but nothing connects the two: the car never picks anything up, and no job ever completes early. Making the car actually run the deliveries is the obvious next step and gives the city a point to all that highlighted activity.

## What Changes

- **BREAKING**: `Car` now requires a `DeliveryBoard` to construct (`Car(city, jobs_board)`), since it needs to see waiting jobs to choose where to drive.
- When at least one delivery job is waiting and the car isn't already carrying a package, the car targets the waiting job whose pickup building is nearest by shortest road route, and drives there one cell at a time instead of wandering.
- The car commits to its chosen pickup target until it either reaches it or the job expires out from under it; a new, nearer job appearing while en route does not cause it to divert. If its target expires first, it re-evaluates from where it stands (nearest remaining job, or random wandering if none).
- Reaching a road cell next to the pickup building collects the package: the job's pickup highlight disappears, its pickup building becomes free again (reusable by a new job), and the car immediately heads for the job's destination by the same shortest-route logic.
- The car carries at most one package at a time; while carrying one it ignores other waiting jobs.
- Reaching a road cell next to the destination building delivers the package: the job is removed entirely (no expiry applies to a job once its package is collected).
- With no waiting job to pursue and nothing in hand, the car drives at random exactly as it does today.

## Capabilities

### New Capabilities
- `car-delivery`: the car's job-seeking and routing behavior — choosing the nearest waiting job by road distance, driving a shortest route to pick up and then to drop off, and falling back to random driving when there's nothing to do.

### Modified Capabilities
- `delivery-jobs`: a job gains a collected/not-yet-collected state. Collection clears the pickup highlight and frees the pickup building early (instead of only on expiry); a collected job no longer counts toward the waiting-job cap or the 15-second expiry, but its destination building stays reserved until the job is delivered and removed.
- `car-driving`: the existing random-direction movement rule now applies only while the car has no delivery job to pursue; directed movement while pursuing or carrying a job is specified in `car-delivery` instead.

## Impact

- `city.py`: add a shortest-route query over the road graph (from a cell to the nearest cell adjacent to a target building), reused for both the pickup and destination legs.
- `car.py`: `Car` takes a `jobs_board` dependency, gains target/carrying state, and chooses between route-following and the existing random-walk logic each move; it calls into the board to collect and deliver jobs it reaches.
- `delivery.py`: `DeliveryJob` gains a collected flag; `DeliveryBoard` gains `collect(job)`/`deliver(job)` methods and updates its busy-building and expiry bookkeeping to treat collected jobs differently from waiting ones.
- `app.py`: update the `Car(self.city)` construction call to pass `self.jobs_board`; drop the pickup highlight once a job is marked collected (destination highlight is unaffected until delivery removes the job).
- No change to the delivery job spawn/cap/expiry timing rules themselves, beyond scoping them to "waiting" (not yet collected) jobs.
