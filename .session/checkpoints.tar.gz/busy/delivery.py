"""Delivery jobs: random pickup/destination building pairs that spawn and expire over time."""

import random as random_module

SPAWN_INTERVAL_TICKS = 3
JOB_LIFETIME_TICKS = 15
MAX_WAITING_JOBS = 3
BASE_PAYOUT = 10
PAYOUT_PER_ROAD_CELL = 1


class DeliveryJob:
    def __init__(self, pickup, destination, payout=0):
        self.pickup = pickup
        self.destination = destination
        self.payout = payout
        self.ticks_remaining = JOB_LIFETIME_TICKS
        self.collected = False


class DeliveryBoard:
    """Tracks waiting delivery jobs for a city, advanced one tick at a time."""

    def __init__(self, city, random=random_module):
        self.city = city
        self.random = random
        self.jobs = []
        self.claimed = set()
        self.takings = 0
        self._ticks_since_spawn_attempt = 0

    def waiting_jobs(self):
        return [job for job in self.jobs if not job.collected]

    def unclaimed_waiting_jobs(self):
        return [job for job in self.waiting_jobs() if job not in self.claimed]

    def claim(self, job):
        self.claimed.add(job)

    def busy_buildings(self):
        busy = set()
        for job in self.waiting_jobs():
            busy.add(job.pickup)
        for job in self.jobs:
            busy.add(job.destination)
        return busy

    def free_buildings(self):
        busy = self.busy_buildings()
        return [building for building in self.city.buildings if building not in busy]

    def collect(self, job):
        job.collected = True
        self.claimed.discard(job)

    def deliver(self, job):
        self.takings += job.payout
        self.jobs.remove(job)
        self.claimed.discard(job)

    def tick(self):
        self._age_jobs()
        self._ticks_since_spawn_attempt += 1
        if self._ticks_since_spawn_attempt >= SPAWN_INTERVAL_TICKS:
            self._ticks_since_spawn_attempt = 0
            self._attempt_spawn()

    def _age_jobs(self):
        for job in self.jobs:
            if not job.collected:
                job.ticks_remaining -= 1
        expired = [job for job in self.jobs if not job.collected and job.ticks_remaining <= 0]
        for job in expired:
            self.claimed.discard(job)
        self.jobs = [job for job in self.jobs if job.collected or job.ticks_remaining > 0]

    def _attempt_spawn(self):
        if len(self.waiting_jobs()) >= MAX_WAITING_JOBS:
            return
        free = self.free_buildings()
        if len(free) < 2:
            return
        pickup, destination = self.random.sample(free, 2)
        route = self.city.route_between_buildings(pickup, destination)
        payout = BASE_PAYOUT + PAYOUT_PER_ROAD_CELL * len(route)
        self.jobs.append(DeliveryJob(pickup, destination, payout=payout))
