from app import DESTINATION_STYLE, PICKUP_STYLE, draw
from car import Car
from city import City
from delivery import DeliveryBoard, DeliveryJob


def style_at(text, city, x, y):
    """The style of the cell at (x, y), by its position among draw()'s per-cell appends."""
    return text.spans[y * city.width + x].style


def test_the_car_is_drawn_over_its_cell():
    city = City.load()
    car = Car(city, DeliveryBoard(city))
    plain_text = draw(city)
    car_text = draw(city, car)

    offset = car.y * (city.width + 1) + car.x

    assert car_text.plain[offset] != plain_text.plain[offset]
    assert car_text.plain[offset] == "●"


def test_only_the_cars_cell_changes():
    city = City.load()
    car = Car(city, DeliveryBoard(city))
    plain_text = draw(city)
    car_text = draw(city, car)

    offset = car.y * (city.width + 1) + car.x
    without_car = car_text.plain[:offset] + plain_text.plain[offset] + car_text.plain[offset + 1 :]

    assert without_car == plain_text.plain


def test_pickup_and_destination_buildings_are_highlighted_distinctly():
    city = City.load()
    pickup_building, destination_building = city.buildings[0], city.buildings[1]
    job = DeliveryJob(pickup_building, destination_building)

    plain_text = draw(city)
    jobs_text = draw(city, jobs=[job])

    px, py = next(iter(pickup_building))
    dx, dy = next(iter(destination_building))

    assert style_at(jobs_text, city, px, py) == PICKUP_STYLE[1]
    assert style_at(jobs_text, city, dx, dy) == DESTINATION_STYLE[1]
    assert style_at(jobs_text, city, px, py) != style_at(plain_text, city, px, py)
    assert style_at(jobs_text, city, px, py) != style_at(jobs_text, city, dx, dy)


def test_collected_jobs_pickup_highlight_is_removed_but_destination_remains():
    city = City.load()
    pickup_building, destination_building = city.buildings[0], city.buildings[1]
    job = DeliveryJob(pickup_building, destination_building)
    job.collected = True

    plain_text = draw(city)
    jobs_text = draw(city, jobs=[job])

    px, py = next(iter(pickup_building))
    dx, dy = next(iter(destination_building))

    assert style_at(jobs_text, city, px, py) == style_at(plain_text, city, px, py)
    assert style_at(jobs_text, city, dx, dy) == DESTINATION_STYLE[1]


def test_only_job_building_cells_change_style():
    city = City.load()
    pickup_building, destination_building = city.buildings[0], city.buildings[1]
    job = DeliveryJob(pickup_building, destination_building)

    plain_text = draw(city)
    jobs_text = draw(city, jobs=[job])

    changed_cells = {
        (x, y)
        for y in range(city.height)
        for x in range(city.width)
        if style_at(jobs_text, city, x, y) != style_at(plain_text, city, x, y)
    }

    assert changed_cells == set(pickup_building) | set(destination_building)
