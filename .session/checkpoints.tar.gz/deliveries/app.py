"""Shows the city map in the terminal. Run with `python app.py`; press q to quit."""

from rich.text import Text
from textual.app import App
from textual.widgets import Footer, Header, Static

from car import Car
from city import BUILDING, PARK, ROAD, City
from delivery import DeliveryBoard

# How each kind of cell is drawn: (character, style).
CELL_STYLES = {
    ROAD: (" ", "on grey30"),
    BUILDING: ("▒", "tan on grey19"),
    PARK: ("♣", "green on dark_green"),
}

# The car is drawn on top of whatever cell it's on.
CAR_STYLE = ("●", "bold yellow on grey30")

# A job's pickup and destination buildings are drawn in their own colours,
# on top of the ordinary building styling.
PICKUP_STYLE = ("▒", "black on dark_orange")
DESTINATION_STYLE = ("▒", "black on deep_sky_blue3")


def draw(city, car=None, jobs=()):
    highlights = {}
    for job in jobs:
        if not job.collected:
            for cell in job.pickup:
                highlights[cell] = PICKUP_STYLE
        for cell in job.destination:
            highlights[cell] = DESTINATION_STYLE

    text = Text()
    for y, row in enumerate(city.rows):
        for x, cell in enumerate(row):
            if car is not None and (x, y) == (car.x, car.y):
                text.append(*CAR_STYLE)
            elif (x, y) in highlights:
                text.append(*highlights[(x, y)])
            else:
                text.append(*CELL_STYLES[cell])
        text.append("\n")
    return text


class CityApp(App):
    TITLE = "City"
    CSS = """
    Screen { align: center middle; }
    #map { width: auto; height: auto; }
    """
    BINDINGS = [("q", "quit", "Quit")]

    def __init__(self):
        super().__init__()
        self.city = City.load()
        self.jobs_board = DeliveryBoard(self.city)
        self.car = Car(self.city, self.jobs_board)

    def compose(self):
        yield Header()
        yield Static(draw(self.city, self.car, self.jobs_board.jobs), id="map")
        yield Footer()

    def on_mount(self):
        self.set_interval(1 / 4, self.drive)
        self.set_interval(1, self.tick_jobs)

    def drive(self):
        self.car.move()
        self.redraw()

    def tick_jobs(self):
        self.jobs_board.tick()
        self.redraw()

    def redraw(self):
        self.query_one("#map", Static).update(draw(self.city, self.car, self.jobs_board.jobs))


if __name__ == "__main__":
    CityApp().run()
