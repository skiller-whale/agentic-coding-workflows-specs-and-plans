"""The city: a fixed grid of roads, buildings and parks, read from city_map.txt."""

from collections import deque
from pathlib import Path

ROAD = "."
BUILDING = "#"
PARK = "T"

MAP_PATH = Path(__file__).with_name("city_map.txt")


class City:
    def __init__(self, rows):
        self.rows = rows
        self.width = len(rows[0])
        self.height = len(rows)
        self.buildings = self._find_buildings()

    @classmethod
    def load(cls, path=MAP_PATH):
        return cls(path.read_text().splitlines())

    def cell(self, x, y):
        return self.rows[y][x]

    def is_road(self, x, y):
        return self.cell(x, y) == ROAD

    def road_neighbors(self, x, y):
        neighbors = []
        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.width and 0 <= ny < self.height and self.is_road(nx, ny):
                neighbors.append((nx, ny))
        return neighbors

    def all_road_cells(self):
        return [
            (x, y)
            for y in range(self.height)
            for x in range(self.width)
            if self.is_road(x, y)
        ]

    def route_to_building(self, start, building):
        """The shortest road route from `start` to a road cell adjacent to `building`.

        Returns the path as a list of cells from `start` to the nearest such
        cell (inclusive), or `None` if no cell adjacent to `building` is
        reachable from `start` along the roads.
        """
        goals = {
            (nx, ny)
            for bx, by in building
            for nx, ny in self.road_neighbors(bx, by)
        }
        if start in goals:
            return [start]

        came_from = {start: None}
        queue = deque([start])
        while queue:
            cell = queue.popleft()
            if cell in goals:
                path = []
                while cell is not None:
                    path.append(cell)
                    cell = came_from[cell]
                path.reverse()
                return path
            for neighbor in self.road_neighbors(*cell):
                if neighbor not in came_from:
                    came_from[neighbor] = cell
                    queue.append(neighbor)
        return None

    def _find_buildings(self):
        """Group orthogonally-contiguous building cells into individual buildings."""
        buildings = []
        visited = set()
        for y in range(self.height):
            for x in range(self.width):
                if self.cell(x, y) != BUILDING or (x, y) in visited:
                    continue
                group = set()
                stack = [(x, y)]
                visited.add((x, y))
                while stack:
                    cx, cy = stack.pop()
                    group.add((cx, cy))
                    for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
                        nx, ny = cx + dx, cy + dy
                        if (
                            0 <= nx < self.width
                            and 0 <= ny < self.height
                            and self.cell(nx, ny) == BUILDING
                            and (nx, ny) not in visited
                        ):
                            visited.add((nx, ny))
                            stack.append((nx, ny))
                buildings.append(frozenset(group))
        return buildings
