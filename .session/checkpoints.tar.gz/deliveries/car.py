"""A car that seeks out and runs delivery jobs, driving at random when there's nothing to do."""

import random as random_module


class Car:
    def __init__(self, city, jobs_board, random=random_module):
        self.city = city
        self.jobs_board = jobs_board
        self.random = random
        self.x, self.y = self.random.choice(city.all_road_cells())
        self.prev = None
        self.target_job = None
        self.carrying = False
        self.route = []

    def move(self):
        if self.carrying:
            self._advance_route(self._deliver)
        elif self.target_job is not None and self.target_job in self.jobs_board.jobs:
            self._advance_route(self._collect)
        else:
            self.target_job = None
            self.route = []
            if self._pick_target():
                self._advance_route(self._collect)
            else:
                self._random_move()

    def _pick_target(self):
        candidates = []
        best_length = None
        for job in self.jobs_board.waiting_jobs():
            route = self.city.route_to_building((self.x, self.y), job.pickup)
            if route is None:
                continue
            if best_length is None or len(route) < best_length:
                best_length = len(route)
                candidates = [(job, route)]
            elif len(route) == best_length:
                candidates.append((job, route))
        if not candidates:
            return False
        job, route = self.random.choice(candidates)
        self.target_job = job
        self.route = route[1:]
        return True

    def _advance_route(self, on_arrival):
        if self.route:
            next_cell = self.route.pop(0)
            self.prev = (self.x, self.y)
            self.x, self.y = next_cell
        if not self.route:
            on_arrival()

    def _collect(self):
        job = self.target_job
        self.jobs_board.collect(job)
        self.carrying = True
        route = self.city.route_to_building((self.x, self.y), job.destination)
        self.route = route[1:] if route else []

    def _deliver(self):
        self.jobs_board.deliver(self.target_job)
        self.target_job = None
        self.carrying = False
        self.route = []

    def _random_move(self):
        candidates = [
            cell
            for cell in self.city.road_neighbors(self.x, self.y)
            if cell != self.prev
        ]
        if not candidates:
            candidates = [self.prev]
        next_cell = self.random.choice(candidates)
        self.prev = (self.x, self.y)
        self.x, self.y = next_cell
